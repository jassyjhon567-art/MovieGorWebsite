Cine Focus update
- Videos page includes the featured 16:9 banner carousel from data/banners.json.
- Banner carousel auto-advances every 3 seconds and supports swipe/drag and manual controls.
- Drama poster rail auto-advances every 3 seconds, supports touch scrolling, and wraps to the beginning.
- Watch and Download actions are visible on watch/detail screens. A valid downloadUrl must be configured for an actual download to succeed.
- Add/edit featured banners in data/banners.json; set active=true and provide image, title, and optionally contentId.
- Deploy the contents of the cinework folder as the Cloudflare Pages output directory (index.html must be at its root).
