/* Firebase Realtime Database bootstrap for Cine Focus. */
(function(){
  'use strict';
  const cfg = window.CF_FIREBASE_CONFIG;
  const valid = cfg && cfg.apiKey && cfg.projectId && cfg.databaseURL;
  window.CF_FIREBASE = { enabled:false, app:null, auth:null, db:null, ready:Promise.resolve(false) };
  if (!valid) return;
  window.CF_FIREBASE.ready = new Promise(resolve => {
    if (!window.firebase || !firebase.database || !firebase.auth) {
      console.warn('[Cine Focus] Firebase compat SDKs did not load.');
      resolve(false); return;
    }
    try {
      const app = firebase.apps && firebase.apps.length ? firebase.app() : firebase.initializeApp(cfg);
      window.CF_FIREBASE.app = app;
      window.CF_FIREBASE.auth = firebase.auth();
      window.CF_FIREBASE.db = firebase.database();
      window.CF_FIREBASE.enabled = true;
      resolve(true);
    } catch(err) { console.error('[Cine Focus] Firebase initialization failed:', err); resolve(false); }
  });
})();