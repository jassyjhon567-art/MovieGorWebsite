/* Cine Focus – local Content Manager.
   Edits are saved in THIS browser only (LocalStorage). To publish for everyone, export the
   JSON files and replace the files in /data, then redeploy. No passwords or keys live here. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const { $, $$, esc, icon, Data, Store } = CF;
  const V = CF.views, A = CF.actions;
  const S = () => CF.state;

  const ITEM = [
    ['id', 'Content ID', 'text'], ['type', 'Type', 'select', Data.TYPES], ['title', 'Title', 'text'], ['altTitle', 'Alternative title', 'text'],
    ['description', 'Description', 'textarea'], ['poster', 'Poster URL (3:4)', 'text'], ['thumbnail', 'Thumbnail URL (16:9)', 'text'], ['banner', 'Banner URL', 'text'],
    ['language', 'Language', 'text'], ['genres', 'Genres (comma separated)', 'list'], ['tags', 'Tags (comma separated)', 'list'], ['cast', 'Cast (comma separated)', 'list'],
    ['category', 'Category', 'text'], ['releaseYear', 'Release year', 'number'], ['duration', 'Duration (seconds)', 'number'], ['rating', 'Rating (leave empty if none)', 'number'],
    ['views', 'Views', 'number'], ['videoUrl', 'Media URL (direct MP4 or HLS .m3u8)', 'text'], ['downloadUrl', 'Downloadable file URL (optional)', 'text'],
    ['aspectRatio', 'Media ratio (player layout)', 'select', Data.RATIOS], ['subtitles', 'Subtitles – one per line: Label|lang|URL', 'subs'],
    ['status', 'Status (drama / series)', 'select', ['', 'ongoing', 'completed']], ['dramaId', 'Parent drama/series ID (episodes only)', 'text'],
    ['seasonNumber', 'Season number', 'number'], ['episodeNumber', 'Episode number', 'number'], ['releaseDate', 'Release date (episodes)', 'text'], ['country', 'Country', 'text'],
    ['order', 'Display order', 'number'], ['featured', 'Featured', 'bool'], ['trending', 'Trending', 'bool'], ['newArrival', 'New arrival', 'bool'], ['published', 'Published', 'bool']
  ];
  const BANNER = [['id', 'Banner ID', 'text'], ['image', 'Banner image URL (16:9)', 'text'], ['title', 'Title', 'text'], ['description', 'Short description', 'textarea'], ['category', 'Category', 'text'], ['buttonText', 'Button text', 'text'], ['contentId', 'Destination content ID', 'text'], ['order', 'Display order', 'number'], ['active', 'Active', 'bool']];
  const SECTION = [['id', 'Section ID', 'text'], ['title', 'Title', 'text'], ['icon', 'Icon (emoji, optional)', 'text'], ['subtitle', 'Subtitle', 'text'], ['type', 'Section type', 'select', ['rail', 'continue']], ['card', 'Card style', 'select', ['auto', 'poster', 'video']], ['layout', 'Layout', 'select', ['rail', 'grid']], ['limit', 'Number of items', 'number'], ['order', 'Display order', 'number'], ['visible', 'Show', 'bool'], ['seeAll', 'Show “See All”', 'bool'], ['showEmpty', 'Show when empty', 'bool'], ['rule', 'Filter rule (JSON)', 'json']];

  const field = (f, o) => {
    const [k, label, kind, opts] = f; let v = o[k];
    if (kind === 'list') v = Array.isArray(v) ? v.join(', ') : (v || '');
    if (kind === 'subs') v = (Array.isArray(v) ? v : []).map(s => [s.label || '', s.lang || '', s.src].join('|')).join('\n');
    if (kind === 'json') v = JSON.stringify(v || {}, null, 1);
    v = v == null ? '' : v;
    if (kind === 'textarea' || kind === 'subs' || kind === 'json') return `<label>${esc(label)}<textarea name="${k}" rows="${kind === 'textarea' ? 3 : 4}">${esc(v)}</textarea></label>`;
    if (kind === 'select') return `<label>${esc(label)}<select name="${k}">${opts.map(x => `<option value="${esc(x)}" ${String(v) === String(x) || (!v && x === opts[0]) ? 'selected' : ''}>${esc(x || '—')}</option>`).join('')}</select></label>`;
    if (kind === 'bool') return `<label class="chk"><input type="checkbox" name="${k}" ${o[k] === undefined ? (['published', 'active', 'visible', 'seeAll'].includes(k) ? 'checked' : '') : (o[k] ? 'checked' : '')}> ${esc(label)}</label>`;
    return `<label>${esc(label)}<input name="${k}" type="${kind === 'number' ? 'number' : 'text'}" ${kind === 'number' ? 'step="any"' : ''} value="${esc(v)}"></label>`;
  };
  function read(form, fields) {
    const o = {};
    for (const [k, label, kind] of fields) {
      const el = form.elements[k]; if (!el) continue; let v;
      if (kind === 'bool') { o[k] = el.checked; continue; }
      v = el.value.trim(); if (v === '') continue;
      if (kind === 'number') { v = Number(v); if (isNaN(v)) throw new Error(label + ' must be a number.'); }
      else if (kind === 'list') v = v.split(',').map(s => s.trim()).filter(Boolean);
      else if (kind === 'subs') v = v.split('\n').map(l => l.trim()).filter(Boolean).map(l => { const p = l.split('|'); return { label: (p[0] || '').trim(), lang: (p[1] || '').trim(), src: p.slice(2).join('|').trim() }; }).filter(s => s.src);
      else if (kind === 'json') { try { v = JSON.parse(v); } catch (e) { throw new Error(label + ' is not valid JSON.'); } if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error(label + ' must be a JSON object.'); }
      o[k] = v;
    }
    return o;
  }
  function commit() {
    if (!Store.set('override', Data.raw)) CF.toast('Saved for this session only – browser storage is full or blocked.');
    Data.usingOverride = true; Data.build();
  }
  function form(title, fields, obj, onSave) {
    const d = CF.modal(`<form method="dialog" class="dlg form" id="aform"><h2>${esc(title)}</h2>${fields.map(f => field(f, obj)).join('')}<p class="hint" id="aerr" role="alert" style="color:var(--pink)"></p><div class="dlg-actions"><button value="cancel" class="btn ghost" formnovalidate>Cancel</button><button value="save" class="btn primary">Save</button></div></form>`);
    $('#aform', d).addEventListener('submit', e => {
      if (e.submitter && e.submitter.value === 'cancel') return;
      try { const o = read(e.target, fields); onSave(o); } catch (er) { e.preventDefault(); $('#aerr', d).textContent = er.message; return; }
      commit(); CF.toast('Saved'); setTimeout(() => CF.render(true), 0);
    });
  }
  const idOK = id => /^[\w.-]+$/.test(id || '');

  /* items */
  A.aedit = el => editItem(el.dataset.id);
  A.anew = () => editItem('');
  function editItem(id) {
    const arr = Data.raw.content.items = Array.isArray(Data.raw.content.items) ? Data.raw.content.items : [];
    const idx = arr.findIndex(x => x && x.id === id), cur = idx >= 0 ? arr[idx] : { type: 'movie', published: true, aspectRatio: '16:9', id: '' };
    form(idx >= 0 ? 'Edit content' : 'Add content', ITEM, cur, o => {
      if (!idOK(o.id)) throw new Error('Content ID is required (letters, numbers, dot, dash, underscore).');
      if (!o.title) throw new Error('Title is required.');
      if (arr.some((x, i) => x && x.id === o.id && i !== idx)) throw new Error('That Content ID is already used.');
      if (o.type === 'episode' && !o.dramaId) throw new Error('Episodes need a Parent drama/series ID.');
      if (idx >= 0) arr[idx] = o; else arr.push(o);
    });
  }
  A.adel = async el => {
    const arr = Data.raw.content.items, it = arr.find(x => x && x.id === el.dataset.id); if (!it) return;
    const kids = arr.filter(x => x && x.type === 'episode' && x.dramaId === it.id).length;
    if (await CF.confirm(`Delete "${it.title}"${kids ? ` and its ${kids} episode${kids > 1 ? 's' : ''}` : ''}? This affects this browser only.`, 'Delete')) {
      Data.raw.content.items = arr.filter(x => x && x.id !== it.id && x.dramaId !== it.id); commit(); CF.render(true);
    }
  };
  /* banners */
  const banners = () => (Data.raw.banners.banners = Array.isArray(Data.raw.banners.banners) ? Data.raw.banners.banners : []);
  A.bedit = el => bannerForm(el.dataset.id);
  A.bnew = () => bannerForm('');
  function bannerForm(id) {
    const a = banners(), idx = a.findIndex(x => x.id === id), cur = idx >= 0 ? a[idx] : { active: true };
    form(idx >= 0 ? 'Edit banner' : 'Add banner', BANNER, cur, o => {
      if (!idOK(o.id)) throw new Error('Banner ID is required.'); if (!o.title) throw new Error('Title is required.');
      if (a.some((x, i) => x.id === o.id && i !== idx)) throw new Error('That Banner ID is already used.');
      if (o.image === undefined) o.image = '';
      if (idx >= 0) a[idx] = o; else a.push(o);
    });
  }
  A.bdel = async el => { if (await CF.confirm('Delete this banner?', 'Delete')) { Data.raw.banners.banners = banners().filter(x => x.id !== el.dataset.id); commit(); CF.render(true); } };
  /* sections */
  const secs = () => { const p = S().adminPage, s = Data.raw.sections; s[p] = Array.isArray(s[p]) ? s[p] : []; s[p].sort((a, b) => (a.order == null ? 9999 : a.order) - (b.order == null ? 9999 : b.order)); return s[p]; };
  A.sedit = el => secForm(el.dataset.id);
  A.snew = () => secForm('');
  function secForm(id) {
    const a = secs(), idx = a.findIndex(x => x.id === id), cur = idx >= 0 ? a[idx] : { visible: true, seeAll: true, type: 'rail', rule: { types: ['movie'] }, order: (a.length + 1) * 10 };
    form(idx >= 0 ? 'Edit section' : 'Add section', SECTION, cur, o => {
      if (!idOK(o.id)) throw new Error('Section ID is required.'); if (!o.title) throw new Error('Title is required.');
      if (a.some((x, i) => x.id === o.id && i !== idx)) throw new Error('That Section ID is already used.');
      if (idx >= 0) a[idx] = o; else a.push(o);
    });
  }
  A.sdel = async el => { if (await CF.confirm('Delete this section?', 'Delete')) { const p = S().adminPage; Data.raw.sections[p] = secs().filter(x => x.id !== el.dataset.id); commit(); CF.render(true); } };
  A.smove = el => { const a = secs(), i = a.findIndex(x => x.id === el.dataset.id), j = i + +el.dataset.d; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; a.forEach((x, k) => { x.order = (k + 1) * 10; }); commit(); CF.render(true); };
  A.svis = el => { const x = secs().find(s => s.id === el.dataset.id); if (x) { x.visible = x.visible === false; commit(); CF.render(true); } };
  A.spage = el => { S().adminPage = el.dataset.v; CF.render(true); };
  A.sfilters = el => {
    const kind = el.dataset.kind, ta = $('#f_' + kind);
    try { const v = JSON.parse(ta.value); if (!Array.isArray(v) || v.some(f => !f || !f.label)) throw 0; Data.raw.sections[kind + 'Filters'] = v; commit(); CF.toast('Filters saved'); }
    catch (e) { CF.toast('Filters must be a JSON array of objects with a "label".'); }
  };
  /* data tab */
  A.aexport = el => {
    const w = el.dataset.what, data = w === 'content' ? Data.raw.content : w === 'banners' ? Data.raw.banners : Data.raw.sections;
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })); a.download = w + '.json'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  };
  CF.changes.aimport = async el => {
    let n = 0;
    for (const f of el.files) {
      try {
        const j = JSON.parse(await f.text());
        if (j && Array.isArray(j.items)) Data.raw.content = j; else if (j && Array.isArray(j.banners)) Data.raw.banners = j; else if (j && (j.home || j.videos || j.drama)) Data.raw.sections = j; else throw new Error('unrecognised');
        n++;
      } catch (e) { CF.toast(f.name + ': not a valid Cine Focus JSON file.'); }
    }
    if (n) { commit(); CF.toast(n + ' file(s) imported'); CF.render(true); }
  };
  A.areset = async () => { if (await CF.confirm('Discard local content edits and reload the files in /data?', 'Reset')) { Store.del('override'); try { await Data.load(true); } catch (e) { CF.toast(e.message); } CF.render(true); } };
  CH_filter();
  function CH_filter() { CF.changes.afilter = () => { const b = $('#abody'); if (b) b.innerHTML = itemRows(); }; }

  function itemRows() {
    const q = ($('#afilter') ? $('#afilter').value : '').toLowerCase(), t = $('#atype') ? $('#atype').value : '';
    const list = (Data.raw.content.items || []).filter(x => x && (!t || x.type === t) && (!q || (x.title + ' ' + x.id).toLowerCase().includes(q)));
    return (list.slice(0, 200).map(x => `<div class="arow ${x.published === false ? 'off' : ''}"><div><b>${esc(x.title)}</b><small>${esc(x.type)} · ${esc(x.id)}${x.dramaId ? ' · in ' + esc(x.dramaId) : ''}${x.published === false ? ' · hidden' : ''}</small></div><button class="btn ghost" data-action="aedit" data-id="${esc(x.id)}">Edit</button><button class="btn ghost danger" data-action="adel" data-id="${esc(x.id)}" aria-label="Delete ${esc(x.title)}">${icon('trash', '')}</button></div>`).join('') || CF.empty('No matching content')) + (list.length > 200 ? '<p class="hint">Showing the first 200 – use the filter to narrow down.</p>' : '');
  }

  const TABS = [['content', 'Content'], ['banners', 'Banners'], ['sections', 'Sections'], ['data', 'Data']];
  V.admin = (a, q) => {
    const tab = S().adminTab; let body = '';
    if (tab === 'content') body = `<div class="toolbar"><input id="afilter" type="search" placeholder="Filter by title or ID" aria-label="Filter content" data-change="afilter"><select id="atype" data-change="afilter" aria-label="Type">${['', ...Data.TYPES].map(t => `<option value="${t}">${t || 'All types'}</option>`).join('')}</select><button class="btn primary sm" data-action="anew">${icon('plus')}Add content</button></div><div id="abody">${itemRows()}</div>`;
    else if (tab === 'banners') body = `<div class="toolbar"><button class="btn primary sm" data-action="bnew">${icon('plus')}Add banner</button></div>${banners().slice().sort((x, y) => (x.order || 9999) - (y.order || 9999)).map(b => `<div class="arow ${b.active === false ? 'off' : ''}"><div><b>${esc(b.title)}</b><small>#${esc(b.order == null ? '–' : b.order)} · ${esc(b.id)}${b.contentId ? ' → ' + esc(b.contentId) : ''}${b.active === false ? ' · inactive' : ''}</small></div><button class="btn ghost" data-action="bedit" data-id="${esc(b.id)}">Edit</button><button class="btn ghost danger" data-action="bdel" data-id="${esc(b.id)}" aria-label="Delete ${esc(b.title)}">${icon('trash')}</button></div>`).join('') || CF.empty('No banners')}`;
    else if (tab === 'sections') {
      const p = S().adminPage, l = secs();
      body = `<div class="chips">${['home', 'videos', 'drama'].map(x => `<button class="chip ${x === p ? 'on' : ''}" data-action="spage" data-v="${x}">${x[0].toUpperCase() + x.slice(1)} page</button>`).join('')}</div><div class="toolbar"><button class="btn primary sm" data-action="snew">${icon('plus')}Add section</button></div>
      ${l.map((s, i) => `<div class="arow ${s.visible === false ? 'off' : ''}"><div><b>${esc((s.icon || '') + ' ' + s.title)}</b><small>${esc(s.id)} · ${esc(JSON.stringify(s.rule || {}))}</small></div><button class="iconbtn" data-action="smove" data-d="-1" data-id="${esc(s.id)}" aria-label="Move up" ${i ? '' : 'disabled'}>${icon('up')}</button><button class="iconbtn" data-action="smove" data-d="1" data-id="${esc(s.id)}" aria-label="Move down" ${i < l.length - 1 ? '' : 'disabled'}>${icon('down')}</button><button class="btn ghost" data-action="svis" data-id="${esc(s.id)}">${s.visible === false ? 'Show' : 'Hide'}</button><button class="btn ghost" data-action="sedit" data-id="${esc(s.id)}">Edit</button><button class="btn ghost danger" data-action="sdel" data-id="${esc(s.id)}" aria-label="Delete ${esc(s.title)}">${icon('trash')}</button></div>`).join('') || CF.empty('No sections on this page')}
      <h3 class="h3">Filter chips</h3><p class="hint">JSON array: <code>{"label":"Action","rule":{"genre":"Action"}}</code>. An entry without a rule shows the page's sections.</p>
      <div class="form">${['video', 'drama'].map(k => `<label>${k[0].toUpperCase() + k.slice(1)} page filters<textarea id="f_${k}" rows="6">${esc(JSON.stringify(Data.filters(k), null, 1))}</textarea></label><p><button class="btn ghost sm" data-action="sfilters" data-kind="${k}">Save ${k} filters</button></p>`).join('')}</div>`;
    } else body = `<div class="warn"><b>Local only.</b> ${Data.usingOverride ? 'This browser is using locally edited content.' : 'This browser is using the files in /data.'} Changes here do not update the website for other visitors.</div>
      <h3 class="h3">Publish for everyone</h3><p class="desc">1) Export the three files below. 2) Replace <code>data/content.json</code>, <code>data/banners.json</code> and <code>data/sections.json</code> in your project. 3) Redeploy to your static host. Never put passwords or API keys in these files.</p>
      <div class="actions">${['content', 'banners', 'sections'].map(w => `<button class="btn ghost" data-action="aexport" data-what="${w}">${icon('download')}${w}.json</button>`).join('')}</div>
      <h3 class="h3">Import</h3><div class="form"><label>Choose one or more exported JSON files<input type="file" accept=".json,application/json" multiple data-change="aimport"></label></div>
      <h3 class="h3">Reset</h3><div class="actions"><button class="btn danger" data-action="areset">${icon('retry')}Discard local edits</button></div>
      ${Data.errors.length ? `<h3 class="h3">Data warnings</h3>${Data.errors.map(e => `<p class="hint">${esc(e)}</p>`).join('')}` : ''}`;
    return {
      title: 'Content Manager',
      html: `${CF.hdr('Content Manager', { back: 1, right: '' })}<div class="page"><div class="warn"><b>Local editor.</b> Changes are saved in this browser only. Use the Data tab to export JSON for deployment.</div><div class="seg" role="tablist">${TABS.map(([k, l]) => `<button class="${k === tab ? 'on' : ''}" role="tab" aria-selected="${k === tab}" data-action="atab" data-v="${k}">${l}</button>`).join('')}</div>${body}</div>`,
      mount() { const e = q && q.get('edit'); if (e) { history.replaceState(null, '', '#/admin'); S().adminTab = 'content'; editItem(e); } }
    };
  };
  A.atab = el => { S().adminTab = el.dataset.v; CF.render(true); };
})();
