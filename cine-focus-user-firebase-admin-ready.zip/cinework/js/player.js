/* Cine Focus – reusable player for videos, movies, episodes and short films.
   Native <video>; layout (16:9 / 9:16 / 1:1 / auto) comes from the media record. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const { esc, icon, Store } = CF;
  const SPEEDS = [0.75, 1, 1.25, 1.5, 2];
  const RC = { '16:9': 'r169', '9:16': 'r916', '1:1': 'r11', 'auto': 'r169' };
  let hlsLoading = null;
  const loadHls = () => window.Hls ? Promise.resolve() : (hlsLoading = hlsLoading || new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.8/hls.min.js';
    s.onload = res; s.onerror = () => { hlsLoading = null; rej(new Error('The HLS helper library could not be loaded (are you offline?).')); };
    document.head.appendChild(s);
  }));

  /* media: {id,parentId,title,src,aspect,subtitles,poster,editId}
     opts : {hasNext,hasPrev,onNext,onPrev,autoplayNext,autoStart} */
  CF.Player = function (host, media, opts) {
    opts = opts || {};
    const st = Store.settings();
    const subs = media.subtitles || [];
    host.innerHTML = `<div class="pstage"><div class="player ${RC[media.aspect] || 'r169'}" tabindex="0" role="region" aria-label="Video player">
      <video playsinline preload="metadata"${media.poster ? ` poster="${esc(media.poster)}"` : ''}></video>
      <button class="p-big" aria-label="Play">${icon('play')}</button>
      <div class="p-msg" hidden></div>
      <div class="p-ctrl">
        <div class="p-seekrow"><span class="p-cur">0:00</span><input class="p-seek" type="range" min="0" max="1000" step="1" value="0" aria-label="Seek"><span class="p-dur">0:00</span></div>
        <div class="p-btns">
          ${opts.hasPrev ? `<button class="pb p-prev" aria-label="Previous episode">${icon('prev')}</button>` : ''}
          <button class="pb p-play" aria-label="Play">${icon('play')}</button>
          ${opts.hasNext ? `<button class="pb p-next" aria-label="Next episode">${icon('next')}</button>` : ''}
          <span class="sp"></span>
          <button class="pb p-mute" aria-label="Mute">${icon('volume')}</button>
          <input class="p-vol" type="range" min="0" max="1" step="0.05" value="1" aria-label="Volume">
          <button class="pb p-speed" aria-label="Playback speed">1×</button>
          ${subs.length ? `<button class="pb p-cc" aria-label="Subtitles: off" aria-pressed="false">${icon('cc')}</button>` : ''}
          <button class="pb p-fs" aria-label="Fullscreen">${icon('fullscreen')}</button>
        </div></div></div></div>`;
    const $ = s => host.querySelector(s);
    const wrap = $('.player'), v = $('video'), big = $('.p-big'), msg = $('.p-msg'), seek = $('.p-seek'), cur = $('.p-cur'), dur = $('.p-dur');
    const playBtn = $('.p-play'), muteBtn = $('.p-mute'), vol = $('.p-vol'), spd = $('.p-speed'), fs = $('.p-fs'), cc = $('.p-cc');
    let destroyed = false, lastSave = 0, blobURL = null, hls = null, hideT, countT, ccIdx = 0, speedIdx = Math.max(0, SPEEDS.indexOf(+st.speed));
    const cleanups = [];
    const on = (el, ev, fn, o) => { el.addEventListener(ev, fn, o); cleanups.push(() => el.removeEventListener(ev, fn, o)); };

    subs.forEach((s, i) => { const t = document.createElement('track'); t.kind = 'subtitles'; t.label = s.label || s.lang || 'Subtitles ' + (i + 1); t.srclang = s.lang || 'en'; t.src = s.src; v.appendChild(t); });
    v.playbackRate = SPEEDS[speedIdx]; spd.textContent = SPEEDS[speedIdx] + '×';

    const showMsg = (html, cls) => { clearInterval(countT); msg.hidden = false; msg.innerHTML = `<div class="box ${cls || ''}">${html}</div>`; wrap.classList.add('has-msg'); };
    const hideMsg = () => { clearInterval(countT); msg.hidden = true; msg.innerHTML = ''; wrap.classList.remove('has-msg'); };
    const showErr = text => showMsg(`<b>This video can't be played</b><p>${esc(text)}</p><div class="btns"><button class="btn primary sm" data-p="retry">${icon('retry')}Try again</button>${media.editId ? `<a class="btn ghost sm" href="#/admin?edit=${encodeURIComponent(media.editId)}" style="color:#fff">Change source</a>` : ''}</div>`);
    const tryPlay = () => { const p = v.play(); if (p && p.catch) p.catch(() => { /* autoplay blocked: the Play button stays visible */ }); };
    const save = done => {
      const d = v.duration; if (!isFinite(d) || !d) return;
      if (!done && v.currentTime < 2 && !Store.progress(media.id)) return;
      Store.saveProgress(media.id, media.parentId, done ? d : v.currentTime, d, done || v.currentTime / d > 0.95);
    };

    async function load() {
      hideMsg(); wrap.classList.add('loading');
      let url = media.src;
      try { const off = await CF.Downloads.offlineURL(media.id); if (off) { blobURL = off; url = off; } } catch (e) { /* ignore */ }
      if (destroyed) return;
      if (!url) { wrap.classList.remove('loading'); showMsg(`<b>No video source yet</b><p>This title has no media URL. Add a direct MP4 or HLS link in the Content Manager.</p><div class="btns">${media.editId ? `<a class="btn primary sm" href="#/admin?edit=${encodeURIComponent(media.editId)}">Add media URL</a>` : ''}</div>`); return; }
      if (/(youtube\.com|youtu\.be|vimeo\.com|facebook\.com|dailymotion\.com)/i.test(url) || /\.(html?|php|aspx?)(\?|#|$)/i.test(url)) {
        wrap.classList.remove('loading'); showErr('This looks like a web page (for example YouTube or Vimeo), not a direct video file. Use a direct .mp4 or .m3u8 link.'); return;
      }
      try {
        if (/\.m3u8(\?|#|$)/i.test(url) && !v.canPlayType('application/vnd.apple.mpegurl')) {
          await loadHls();
          if (!window.Hls || !window.Hls.isSupported()) throw new Error('This browser cannot play HLS streams.');
          hls = new window.Hls(); hls.loadSource(url); hls.attachMedia(v);
          hls.on(window.Hls.Events.ERROR, (e, d) => { if (d.fatal) { wrap.classList.remove('loading'); showErr('The stream failed to load (' + d.type + '). It may be offline or blocked by CORS.'); } });
        } else { v.src = url; }
      } catch (e) { wrap.classList.remove('loading'); showErr(e.message); }
    }

    const ERR = { 1: 'Playback was aborted.', 2: 'A network error occurred. The host may be offline, or it blocks playback from other websites (CORS / hotlink protection).', 3: 'The file is damaged or uses a codec this browser cannot decode.', 4: 'This address is not a playable video, or the format (for example MKV or DRM-protected media) is not supported by this browser. Use a direct MP4 or HLS link.' };
    on(v, 'error', () => { if (!v.getAttribute('src') && !hls) return; wrap.classList.remove('loading'); showErr(ERR[v.error ? v.error.code : 0] || 'Unknown playback error.'); });
    on(v, 'loadedmetadata', () => {
      wrap.classList.remove('loading');
      if (media.aspect === 'auto' && v.videoWidth) {
        wrap.classList.remove('r169', 'r916', 'r11');
        wrap.classList.add(Math.abs(v.videoWidth - v.videoHeight) < v.videoWidth * .05 ? 'r11' : v.videoWidth < v.videoHeight ? 'r916' : 'r169');
      }
      dur.textContent = isFinite(v.duration) ? CF.fmtTime(v.duration) : 'Live';
      if (st.subtitles && cc && !ccIdx) setCC(1);
      const p = Store.progress(media.id);
      if (opts.autoStart) tryPlay();
      else if (p && !p.done && p.pos > 10 && p.pos < (v.duration || 1e9) - 10) {
        showMsg(`<b>Resume from ${CF.fmtTime(p.pos)}?</b><div class="btns"><button class="btn primary sm" data-p="resume" data-pos="${p.pos}">Resume</button><button class="btn ghost sm" data-p="restart" style="color:#fff">Start Over</button></div>`);
      }
    });
    on(v, 'timeupdate', () => {
      if (isFinite(v.duration) && v.duration) seek.value = v.currentTime / v.duration * 1000;
      cur.textContent = CF.fmtTime(v.currentTime);
      const n = Date.now(); if (n - lastSave > 5000 && !v.paused) { save(); lastSave = n; }
    });
    on(v, 'play', () => { wrap.classList.add('playing'); playBtn.innerHTML = icon('pause'); playBtn.setAttribute('aria-label', 'Pause'); big.setAttribute('aria-label', 'Pause'); poke(); });
    on(v, 'pause', () => { wrap.classList.remove('playing'); playBtn.innerHTML = icon('play'); playBtn.setAttribute('aria-label', 'Play'); big.setAttribute('aria-label', 'Play'); save(); });
    on(v, 'waiting', () => wrap.classList.add('loading'));
    on(v, 'playing', () => wrap.classList.remove('loading'));
    on(v, 'canplay', () => wrap.classList.remove('loading'));
    on(v, 'volumechange', () => { muteBtn.innerHTML = icon(v.muted || v.volume === 0 ? 'mute' : 'volume'); muteBtn.setAttribute('aria-label', v.muted ? 'Unmute' : 'Mute'); });
    on(v, 'ended', () => {
      save(true);
      if (opts.hasNext) {
        if (opts.autoplayNext) {
          let n = 5;
          const draw = () => showMsg(`<b>Up next</b><p>Next episode starts in ${n}s</p><div class="btns"><button class="btn primary sm" data-p="next">Play now</button><button class="btn ghost sm" data-p="cancel" style="color:#fff">Cancel</button></div>`);
          draw(); countT = setInterval(() => { n--; if (n <= 0) { clearInterval(countT); opts.onNext && opts.onNext(true); } else draw(); }, 1000);
        } else showMsg(`<b>Episode finished</b><div class="btns"><button class="btn primary sm" data-p="next">Next Episode</button><button class="btn ghost sm" data-p="replay" style="color:#fff">Replay</button></div>`);
      } else showMsg(`<b>Finished</b><div class="btns"><button class="btn primary sm" data-p="replay">Replay</button></div>`);
    });

    on(msg, 'click', e => {
      const b = e.target.closest('[data-p]'); if (!b) return; const a = b.dataset.p;
      if (a === 'retry') { if (v.getAttribute('src')) v.removeAttribute('src'); if (hls) { hls.destroy(); hls = null; } load(); }
      else if (a === 'resume') { hideMsg(); v.currentTime = +b.dataset.pos || 0; tryPlay(); }
      else if (a === 'restart' || a === 'replay') { hideMsg(); v.currentTime = 0; tryPlay(); }
      else if (a === 'next') { clearInterval(countT); opts.onNext && opts.onNext(true); }
      else if (a === 'cancel') hideMsg();
    });

    const toggle = () => { if (v.paused) tryPlay(); else v.pause(); };
    on(playBtn, 'click', toggle); on(big, 'click', toggle);
    on(v, 'click', () => { toggle(); poke(); });
    on(v, 'dblclick', () => fullscreen());
    on(seek, 'input', () => { if (isFinite(v.duration)) { v.currentTime = seek.value / 1000 * v.duration; cur.textContent = CF.fmtTime(v.currentTime); } });
    on(vol, 'input', () => { v.volume = +vol.value; v.muted = +vol.value === 0; });
    on(muteBtn, 'click', () => { v.muted = !v.muted; });
    on(spd, 'click', () => { speedIdx = (speedIdx + 1) % SPEEDS.length; v.playbackRate = SPEEDS[speedIdx]; spd.textContent = SPEEDS[speedIdx] + '×'; });
    function setCC(i) {
      ccIdx = i; [...v.textTracks].forEach((t, j) => { t.mode = j === i - 1 ? 'showing' : 'disabled'; });
      if (cc) { const name = i ? (subs[i - 1].label || subs[i - 1].lang || 'on') : 'off'; cc.setAttribute('aria-label', 'Subtitles: ' + name); cc.setAttribute('aria-pressed', i ? 'true' : 'false'); }
    }
    if (cc) on(cc, 'click', () => { setCC((ccIdx + 1) % (subs.length + 1)); CF.toast('Subtitles: ' + (ccIdx ? (subs[ccIdx - 1].label || subs[ccIdx - 1].lang) : 'off')); });
    function fullscreen() {
      const fsEl = document.fullscreenElement || document.webkitFullscreenElement;
      if (fsEl) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); return; }
      const rq = wrap.requestFullscreen || wrap.webkitRequestFullscreen;
      if (rq) rq.call(wrap); else if (v.webkitEnterFullscreen) v.webkitEnterFullscreen(); /* iPhone Safari */
    }
    on(fs, 'click', fullscreen);
    const fsChange = () => { const f = document.fullscreenElement === wrap || document.webkitFullscreenElement === wrap; fs.setAttribute('aria-label', f ? 'Exit fullscreen' : 'Fullscreen'); };
    on(document, 'fullscreenchange', fsChange); on(document, 'webkitfullscreenchange', fsChange);
    const pv = $('.p-prev'), nx = $('.p-next');
    if (pv) on(pv, 'click', () => opts.onPrev && opts.onPrev());
    if (nx) on(nx, 'click', () => opts.onNext && opts.onNext());

    function poke() { wrap.classList.add('show'); clearTimeout(hideT); hideT = setTimeout(() => wrap.classList.remove('show'), 2800); }
    on(wrap, 'pointermove', poke); on(wrap, 'touchstart', poke, { passive: true });
    on(wrap, 'keydown', e => {
      if (e.target.matches('input,button,a')) return;
      const k = e.key;
      if (k === ' ' || k === 'k') { e.preventDefault(); toggle(); }
      else if (k === 'ArrowRight') { v.currentTime += 5; } else if (k === 'ArrowLeft') { v.currentTime -= 5; }
      else if (k === 'ArrowUp') { e.preventDefault(); v.volume = Math.min(1, v.volume + .1); vol.value = v.volume; }
      else if (k === 'ArrowDown') { e.preventDefault(); v.volume = Math.max(0, v.volume - .1); vol.value = v.volume; }
      else if (k === 'm') v.muted = !v.muted; else if (k === 'f') fullscreen(); else return;
      poke();
    });
    const onHide = () => { if (document.hidden) save(); };
    on(document, 'visibilitychange', onHide); on(window, 'pagehide', () => save());

    load();
    return {
      el: wrap,
      destroy() {
        if (destroyed) return; save(); destroyed = true;
        clearTimeout(hideT); clearInterval(countT); cleanups.forEach(f => f());
        try { v.pause(); v.removeAttribute('src'); v.load(); } catch (e) { /* ignore */ }
        if (hls) hls.destroy(); if (blobURL) URL.revokeObjectURL(blobURL);
        if (document.fullscreenElement === wrap) document.exitFullscreen();
      }
    };
  };
})();
