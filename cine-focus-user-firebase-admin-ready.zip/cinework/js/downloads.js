/* Cine Focus – downloads.
   Honest browser-side behaviour:
   - "offline"  : the file was fetched by the app and stored in IndexedDB (needs CORS access + enough storage)
   - "browser"  : the host blocks in-app saving, so a normal browser download/tab was opened (not tracked)
   Nothing is marked as downloaded unless it really was. Only items with a downloadUrl can be downloaded. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const { Store, Data, IDB, esc, enc, icon, $ } = CF;
  const ctrls = {};
  let lastPaint = 0;

  const D = CF.Downloads = {
    recs() { const l = Store.get('downloads', []); return Array.isArray(l) ? l : []; },
    save(l) { Store.set('downloads', l); },
    find(id) { return this.recs().find(r => r.id === id); },
    upsert(r) { const l = this.recs(), i = l.findIndex(x => x.id === r.id); if (i >= 0) l[i] = Object.assign({}, l[i], r); else l.unshift(r); this.save(l); },
    init() {
      const l = this.recs(); let ch = false;
      l.forEach(r => { if (r.status === 'downloading') { r.status = 'failed'; r.error = 'Download was interrupted (page closed or reloaded). Tap Retry.'; ch = true; } });
      if (ch) this.save(l);
    },
    async offlineURL(id) {
      const r = this.find(id); if (!r || r.status !== 'offline') return null;
      try { const b = await IDB.get('file:' + id); return b ? URL.createObjectURL(b) : null; } catch (e) { return null; }
    },
    async start(id) {
      const it = Data.byId[id];
      if (!it || !it.downloadUrl) { CF.toast('This title has no downloadable file.'); return; }
      if (ctrls[id]) { CF.toast('Already downloading.'); return; }
      const base = { id, title: it.title, thumb: CF.thumbOf(it) || CF.posterOf(it), type: it.type, ts: Date.now(), error: '' };
      this.upsert(Object.assign(base, { status: 'downloading', progress: 0, size: 0 }));
      CF.toast('Download started – see the Downloads tab.'); this.paint(true);
      const ctrl = ctrls[id] = new AbortController();
      try {
        const r = await fetch(it.downloadUrl, { signal: ctrl.signal });
        if (!r.ok) throw new Error('The server answered HTTP ' + r.status + '.');
        const total = +r.headers.get('content-length') || 0, chunks = []; let got = 0;
        if (r.body && r.body.getReader) {
          const rd = r.body.getReader();
          for (;;) {
            const { done, value } = await rd.read(); if (done) break;
            chunks.push(value); got += value.length;
            this.upsert({ id, progress: total ? got / total : 0, size: total || got }); this.paint();
          }
        } else { const b = await r.blob(); chunks.push(b); got = b.size; }
        const blob = new Blob(chunks, { type: r.headers.get('content-type') || 'video/mp4' });
        await IDB.put('file:' + id, blob);
        this.upsert({ id, status: 'offline', progress: 1, size: blob.size, ts: Date.now(), error: '' });
        CF.toast('Saved for offline viewing: ' + it.title);
      } catch (e) {
        if (e && e.name === 'AbortError') { this.drop(id); }
        else if (e instanceof TypeError) {
          /* usually CORS or network: fall back to normal browser behaviour */
          const a = document.createElement('a'); a.href = it.downloadUrl; a.download = ''; a.target = '_blank'; a.rel = 'noopener'; document.body.appendChild(a); a.click(); a.remove();
          this.upsert({ id, status: 'browser', progress: 1, error: 'The host does not allow in-app saving (CORS) or the network failed, so the link was opened with your browser\'s normal download. It is not tracked and is not available offline here.' });
          CF.toast('Opened with your browser\'s normal download.');
        } else {
          const quota = e && /quota/i.test(e.name + e.message);
          this.upsert({ id, status: 'failed', error: quota ? 'Not enough browser storage for this file.' : (e && e.message) || 'Download failed.' });
          CF.toast('Download failed.');
        }
      } finally { delete ctrls[id]; this.paint(true); }
    },
    cancel(id) { if (ctrls[id]) ctrls[id].abort(); },
    drop(id) { this.save(this.recs().filter(r => r.id !== id)); IDB.del('file:' + id).catch(() => {}); },
    paint(force) {
      if (!location.hash.startsWith('#/downloads')) return;
      const n = Date.now(); if (!force && n - lastPaint < 400) return; lastPaint = n;
      const b = $('#dlbody'); if (b) b.innerHTML = body();
    }
  };

  const group = t => t === 'video' ? 'video' : (t === 'movie' || t === 'short') ? 'movie' : 'drama';
  const tabOf = r => r.status === 'downloading' ? 'going' : r.status === 'failed' ? 'failed' : 'done';
  const statusText = r => ({ offline: ['Available offline', ''], browser: ['Sent to browser downloads (not tracked)', ''], downloading: ['Downloading… ' + Math.round((r.progress || 0) * 100) + '%', ''], failed: ['Failed', 'bad'] }[r.status] || ['', '']);

  function row(r) {
    const it = Data.byId[r.id], st = statusText(r);
    const open = it && r.status !== 'downloading';
    return `<div class="drow"><div class="dthumb">${CF.img(r.thumb, r.title, '3:4')}</div><div class="dinfo"><b>${esc(r.title)}</b><small>${esc(CF.label[r.type] || '')}${r.size ? ' · ' + CF.fmtSize(r.size) : ''}</small><small class="stt ${st[1]}">${esc(st[0])}</small>${r.status === 'downloading' ? `<div class="dprog"><i style="width:${Math.round((r.progress || 0) * 100)}%"></i></div>` : ''}${r.error ? `<small>${esc(r.error)}</small>` : ''}${!it ? '<small>This title is no longer in the catalogue.</small>' : ''}</div><div class="dact">
      ${open ? `<a class="iconbtn" href="#/watch/${enc(r.id)}" aria-label="Open ${esc(r.title)}">${icon('play')}</a>` : ''}
      ${r.status === 'failed' && it ? `<button class="iconbtn" data-action="dlretry" data-id="${esc(r.id)}" aria-label="Retry download">${icon('retry')}</button>` : ''}
      ${r.status === 'downloading' ? `<button class="iconbtn" data-action="dlcancel" data-id="${esc(r.id)}" aria-label="Cancel download">${icon('close')}</button>` : `<button class="iconbtn" data-action="dlrm" data-id="${esc(r.id)}" aria-label="Remove ${esc(r.title)}">${icon('trash')}</button>`}
    </div></div>`;
  }

  function body() {
    const all = D.recs(), S = CF.state;
    const inTab = all.filter(r => tabOf(r) === S.dlTab && (S.dlType === 'all' || group(r.type) === S.dlType));
    const cnt = t => all.filter(r => tabOf(r) === t).length;
    const tabs = [['done', 'Downloaded'], ['going', 'Downloading'], ['failed', 'Failed']].map(([k, l]) => `<button class="${S.dlTab === k ? 'on' : ''}" data-action="dltab" data-v="${k}">${l}${cnt(k) ? ' (' + cnt(k) + ')' : ''}</button>`).join('');
    const types = [['all', 'All'], ['video', 'Videos'], ['movie', 'Movies'], ['drama', 'Dramas']].map(([k, l]) => `<button class="chip ${S.dlType === k ? 'on' : ''}" data-action="dltype" data-v="${k}">${l}</button>`).join('');
    const msg = S.dlTab === 'done' ? ['Nothing downloaded yet', 'Titles that provide a downloadable file show a Download button on their page. Streaming-only titles cannot be saved.'] : S.dlTab === 'going' ? ['No active downloads', ''] : ['No failed downloads', ''];
    return `<div class="seg" role="tablist" aria-label="Download status">${tabs}</div><div class="chips" aria-label="Filter by type">${types}</div>${inTab.length ? inTab.map(row).join('') : CF.empty(msg[0], msg[1])}<div class="storage" id="storage">Checking storage…</div>`;
  }

  async function storage() {
    const el = $('#storage'); if (!el) return;
    try {
      const e = await navigator.storage.estimate(), pct = e.quota ? Math.min(100, e.usage / e.quota * 100) : 0;
      el.innerHTML = `<div style="display:flex;justify-content:space-between"><span>Browser storage used</span><span>${CF.fmtSize(e.usage) || '0 KB'} of ${CF.fmtSize(e.quota)}</span></div><div class="dprog"><i style="width:${pct.toFixed(1)}%"></i></div><small class="hint">This is the total for this site in your browser. Offline files can be evicted by the browser when the device runs low on space.</small>`;
    } catch (e) { el.innerHTML = '<small class="hint">Storage usage is not available in this browser. Downloads still work where permitted.</small>'; }
  }

  CF.views.downloads = () => ({
    title: 'Downloads',
    html: `${CF.hdr('Downloads', { right: `<button class="iconbtn" data-action="dlclear" aria-label="Clear downloads list">${icon('trash')}</button>` })}<div class="page"><div id="dlbody">${body()}</div></div>`,
    mount() { storage(); }
  });

  const A = CF.actions;
  A.dl = el => D.start(el.dataset.id);
  A.dlretry = el => D.start(el.dataset.id);
  A.dlcancel = el => D.cancel(el.dataset.id);
  A.dlrm = async el => { D.drop(el.dataset.id); D.paint(true); };
  A.dltab = el => { CF.state.dlTab = el.dataset.v; D.paint(true); };
  A.dltype = el => { CF.state.dlType = el.dataset.v; D.paint(true); };
  A.dlclear = async () => {
    if (!D.recs().length) { CF.toast('The list is already empty.'); return; }
    if (await CF.confirm('Remove every item from your downloads list? Offline copies saved in this browser will be deleted.', 'Clear all')) {
      Object.keys(ctrls).forEach(k => ctrls[k].abort());
      D.recs().forEach(r => IDB.del('file:' + r.id).catch(() => {})); D.save([]); D.paint(true); storage();
    }
  };
  CF.downloadCount = () => D.recs().filter(r => r.status === 'offline' || r.status === 'browser').length;
})();
