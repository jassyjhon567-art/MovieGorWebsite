/* Firebase web-app configuration. Public web config; protect data with Firebase Security Rules. */
window.CF_FIREBASE_CONFIG = {
  apiKey: "AIzaSyBNtJLXHfpPt9PKTQOvfyvc3nvhrE3mWr4",
  authDomain: "test-f901f.firebaseapp.com",
  databaseURL: "https://test-f901f-default-rtdb.firebaseio.com",
  projectId: "test-f901f",
  storageBucket: "test-f901f.firebasestorage.app",
  messagingSenderId: "170937085052",
  appId: "1:170937085052:web:cfc6e4a506425eff5d2df9"
};
