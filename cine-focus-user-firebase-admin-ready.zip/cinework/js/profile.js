/* Cine Focus – local guest profile, lists, history and settings. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const { $, esc, enc, icon, Data, Store } = CF;
  const V = CF.views, A = CF.actions, CH = CF.changes;
  const hdr = CF.hdr;

  const mrow = (href, ic, label, sub) => `<a class="mrow" href="${href}">${icon(ic)}<span class="lbl">${esc(label)}${sub ? `<small>${esc(sub)}</small>` : ''}</span>${icon('chev')}</a>`;

  V.profile = () => {
    const p = Store.profile();
    const wl = Store.list('watchlist').filter(x => Data.byId[x.id]).length, fav = Store.list('favorites').filter(x => Data.byId[x.id]).length;
    return {
      title: 'Profile',
      html: `${hdr('Profile', { right: `<a class="iconbtn" href="#/settings" aria-label="Settings">${icon('settings')}</a>` })}<div class="page">
      <div class="pro-top"><div class="pro-av">${CF.avatarHTML()}</div><h2>${esc(p.name)}</h2><p>@${esc(p.username || 'guest')} · Guest profile</p><p style="margin-top:12px"><button class="btn primary sm" data-action="editprofile">${icon('edit')}Edit Profile</button></p></div>
      <div class="stats"><a class="stat" href="#/watchlist"><b>${wl}</b><span>Watch Later</span></a><a class="stat" href="#/downloads"><b>${CF.downloadCount()}</b><span>Downloads</span></a><a class="stat" href="#/favorites"><b>${fav}</b><span>Favorites</span></a></div>
      <div class="menu">${mrow('#/watchlist', 'bookmark', 'My Watchlist')}${mrow('#/history', 'history', 'Watch History')}${mrow('#/continue', 'play', 'Continue Watching')}${mrow('#/downloads', 'download', 'Downloads')}${mrow('#/favorites', 'heart', 'Favorites')}${mrow('#/settings', 'settings', 'Settings')}${mrow('#/help', 'help', 'Help & Support')}${mrow('#/about', 'info', 'About App')}</div>
      <p class="note">This is a local guest profile. It is stored in this browser only and is not synchronised between devices. There is no account or sign-in.${Store.persistent ? '' : ' Browser storage is blocked, so changes will be lost when you close the tab.'}</p></div>`
    };
  };

  function fileToAvatar(file) {
    return new Promise((res, rej) => {
      const fr = new FileReader(); fr.onerror = () => rej(new Error('Could not read the file.'));
      fr.onload = () => {
        const im = new Image(); im.onerror = () => rej(new Error('That file is not a usable image.'));
        im.onload = () => { const s = 256, c = document.createElement('canvas'); c.width = c.height = s; const m = Math.min(im.width, im.height); c.getContext('2d').drawImage(im, (im.width - m) / 2, (im.height - m) / 2, m, m, 0, 0, s, s); res(c.toDataURL('image/jpeg', .85)); };
        im.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  A.editprofile = () => {
    const p = Store.profile(); let fileData = '';
    const d = CF.modal(`<form method="dialog" class="dlg form" id="pform"><h2>Edit Profile</h2><div class="pro-av avprev" id="avprev">${CF.avatarHTML()}</div>
      <label>Display name<input name="name" maxlength="40" required value="${esc(p.name)}"></label>
      <label>Username<input name="username" maxlength="30" pattern="[A-Za-z0-9_.]*" title="Letters, numbers, dot and underscore" value="${esc(p.username)}"></label>
      <label>Avatar image URL<input name="avatar" type="url" placeholder="https://…" value="${esc(p.avatar && !p.avatar.startsWith('data:') ? p.avatar : '')}"></label>
      <label>…or choose an image from this device<input type="file" id="avfile" accept="image/*"></label>
      <p class="hint">Saved in this browser only. Local images are resized to 256×256 before saving.</p>
      <div class="dlg-actions"><button value="cancel" class="btn ghost" formnovalidate>Cancel</button><button value="save" class="btn primary">Save</button></div></form>`);
    $('#avfile', d).addEventListener('change', async e => {
      const f = e.target.files[0]; if (!f) return;
      try { fileData = await fileToAvatar(f); $('#avprev', d).innerHTML = `<img class="avatar" src="${fileData}" alt="">`; } catch (er) { CF.toast(er.message); }
    });
    d.onclose = () => {
      if (d.returnValue !== 'save') return;
      const fd = new FormData($('#pform', d));
      Store.set('profile', { name: String(fd.get('name') || 'Guest').trim() || 'Guest', username: String(fd.get('username') || 'guest').trim() || 'guest', avatar: fileData || String(fd.get('avatar') || '').trim() });
      CF.toast('Profile saved'); CF.render(true);
    };
  };

  /* ---------- lists ---------- */
  function savedView(key, title, emptyMsg) {
    return () => {
      const items = Store.list(key).map(x => Data.byId[x.id]).filter(x => x && x.published);
      return { title, html: `${hdr(title, { back: 1 })}<div class="page">${items.length ? CF.mixedGrid(items, key) : CF.empty(title + ' is empty', emptyMsg)}</div>` };
    };
  }
  V.watchlist = savedView('watchlist', 'My Watchlist', 'Tap Add to Watchlist on any title to save it here.');
  V.favorites = savedView('favorites', 'Favorites', 'Tap Add to Favorites on any title to keep it here.');

  V.continue = () => {
    const c = Object.values(Store.progressAll()).filter(p => p && !p.done && p.pos > 5 && Data.byId[p.id]).sort((a, b) => b.ts - a.ts);
    return { title: 'Continue Watching', html: `${hdr('Continue Watching', { back: 1 })}<div class="page">${c.length ? `<div class="grid-v">${c.map(p => CF.contCard(Data.byId[p.id], p)).join('')}</div>` : CF.empty('Nothing to continue', 'Start a title and your place is saved automatically.')}</div>` };
  };

  V.history = () => {
    const h = Object.values(Store.progressAll()).filter(p => p && Data.byId[p.id]).sort((a, b) => b.ts - a.ts);
    const rows = h.map(p => {
      const it = Data.byId[p.id], par = it.type === 'episode' ? Data.byId[it.dramaId] : null, pct = p.dur ? Math.min(1, p.pos / p.dur) : 0;
      const t = par ? `${par.title} – S${it.seasonNumber} E${it.episodeNumber}` : it.title;
      return `<div class="drow"><a class="thumb" style="flex:0 0 96px" href="#/watch/${enc(it.id)}">${CF.img(CF.thumbOf(it), t, '16:9')}<div class="pbar"><i style="width:${(pct * 100).toFixed(0)}%"></i></div></a><div class="dinfo"><a href="#/watch/${enc(it.id)}"><b>${esc(t)}</b></a><small>${p.done ? 'Completed' : CF.fmtTime(p.pos) + ' of ' + CF.fmtTime(p.dur)} · ${esc(CF.fmtDate(p.ts))}</small></div><button class="iconbtn" data-action="hrm" data-id="${esc(p.id)}" aria-label="Remove ${esc(t)} from history">${icon('close')}</button></div>`;
    }).join('');
    return { title: 'Watch History', html: `${hdr('Watch History', { back: 1, right: h.length ? `<button class="btn ghost sm" data-action="hclear">Clear</button>` : '' })}<div class="page">${rows || CF.empty('No watch history', 'Titles you play will appear here.')}</div>` };
  };
  A.hrm = el => { Store.removeProgress(el.dataset.id); CF.render(true); };
  const clearHistory = async () => { if (await CF.confirm('Clear your watch history and saved playback positions?', 'Clear history')) { Store.del('progress'); CF.toast('Watch history cleared'); CF.render(true); } };
  A.hclear = clearHistory;

  /* ---------- settings ---------- */
  const sw = (key, label, sub, checked) => `<div class="mrow"><span class="lbl"><label for="s_${key}">${esc(label)}</label>${sub ? `<small>${esc(sub)}</small>` : ''}</span><span class="switch"><input id="s_${key}" type="checkbox" role="switch" data-change="setting" data-key="${key}" ${checked ? 'checked' : ''}><span></span></span></div>`;
  V.settings = () => {
    const s = Store.settings();
    return {
      title: 'Settings',
      html: `${hdr('Settings', { back: 1, right: '' })}<div class="page"><div class="menu">
      ${sw('theme', 'Dark theme', 'Turn off for a light appearance', s.theme === 'dark')}
      ${sw('autoplay', 'Autoplay next episode', 'Continue to the next episode when one ends', s.autoplay)}
      ${sw('subtitles', 'Subtitles on by default', 'Only for titles that provide subtitle files', s.subtitles)}
      <div class="mrow"><span class="lbl"><label for="s_speed">Default playback speed</label></span><select id="s_speed" class="sel" data-change="setting" data-key="speed">${[0.75, 1, 1.25, 1.5, 2].map(x => `<option value="${x}" ${+s.speed === x ? 'selected' : ''}>${x}×</option>`).join('')}</select></div></div>
      <div class="menu"><button class="mrow" data-action="hclear">${icon('history')}<span class="lbl">Clear watch history</span></button><button class="mrow" data-action="clearall">${icon('trash')}<span class="lbl">Clear local application data<small>Profile, lists, history, downloads and local content edits</small></span></button></div>
      <p class="note">Settings and data are stored in this browser only and are not synchronised across devices.</p></div>`
    };
  };
  CH.setting = el => {
    const k = el.dataset.key; let v = el.type === 'checkbox' ? el.checked : parseFloat(el.value);
    if (k === 'theme') { v = el.checked ? 'dark' : 'light'; document.documentElement.dataset.theme = v; document.querySelector('meta[name=theme-color]').content = v === 'dark' ? '#030817' : '#EEF3FB'; }
    Store.setSetting(k, v);
  };
  A.clearall = async () => {
    if (await CF.confirm('Delete ALL local data for Cine Focus in this browser (profile, watchlist, favorites, history, downloads and any content edits)? This cannot be undone.', 'Delete everything')) {
      Store.clearAll(); try { await CF.IDB.clear(); } catch (e) { /* ignore */ }
      CF.toast('Local data cleared'); setTimeout(() => { location.hash = '#/home'; location.reload(); }, 600);
    }
  };

  /* ---------- help & about ---------- */
  V.help = () => ({
    title: 'Help & Support',
    html: `${hdr('Help & Support', { back: 1, right: '' })}<div class="page">
    <details class="faq" open><summary>A video says “No video source yet”</summary><p>The title has no media URL. The media source has not been configured yet. Please check back later.</p></details>
    <details class="faq"><summary>A video can't be played</summary><p>The address must point straight to a video file. Web page links (YouTube, Vimeo) do not work. Some hosts block playback from other sites (CORS). MKV files and DRM-protected streams are not supported by browsers.</p></details>
    <details class="faq"><summary>Why is there no Download button?</summary><p>Only titles that have a downloadable file URL show it. Streaming-only titles cannot be saved. If a host blocks in-app saving, the browser's normal download is used instead and is not tracked.</p></details>
    <details class="faq"><summary>Where is my data stored?</summary><p>Your profile, watchlist, history and offline files live in this browser only. Clearing browser data removes them.</p></details>
    <details class="faq"><summary>Will my account and watchlist sync across devices?</summary><p>Cloud sync can be enabled after Firebase credentials are added by the site owner.</p></details></div>`
  });
  V.about = () => ({
    title: 'About',
    html: `${hdr('About Cine Focus', { back: 1, right: '' })}<div class="page"><div class="pro-top"><img src="assets/logos/logo.svg" alt="" width="72" height="72" style="margin:0 auto 10px"><h2>Cine Focus</h2><p>Version 1.0.0</p></div><p class="desc">Cine Focus is a static web app built with HTML, CSS and vanilla JavaScript. Content comes from JSON files you control. Profile, watchlist, history and offline files are stored in your browser. Only publish media you are authorised to share.</p></div>`
  });
})();
