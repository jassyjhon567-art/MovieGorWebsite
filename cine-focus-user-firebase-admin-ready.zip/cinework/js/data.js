/* Cine Focus – content repository. Loads data/*.json (or a local override saved by the
   Content Manager), validates every record, and offers query/search helpers.
   No eval(); invalid records are skipped, never fatal. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const { Store } = CF;
  const TYPES = ['movie', 'series', 'drama', 'episode', 'video', 'short'];
  const RATIOS = ['16:9', '9:16', '1:1', 'auto'];
  const Data = CF.Data = { TYPES, RATIOS, items: [], byId: {}, banners: [], errors: [], raw: null, usingOverride: false };

  async function getJSON(p) {
    const r = await fetch(p, { cache: 'no-cache' });
    if (!r.ok) throw new Error(p + ' could not be loaded (HTTP ' + r.status + ')');
    return r.json();
  }

  Data.load = async function (forceFiles) {
    const ov = forceFiles ? null : Store.get('override', null);
    let c, b, sec, platforms = { platforms: [] }, settings = {};
    // Published Firebase data wins over bundled files. Firebase is the single source of truth
    // once the admin has saved the first data set.
    let remoteLoaded = false;
    try {
      if (window.CF_FIREBASE && await window.CF_FIREBASE.ready) {
        const snap = await window.CF_FIREBASE.db.ref('cineFocus').once('value');
        const remote = snap.val();
        if (remote && remote.content && remote.sections) {
          c = remote.content; b = remote.banners || { banners: [] };
          sec = remote.sections; platforms = remote.platforms || { platforms: [] };
          settings = remote.settings || {}; remoteLoaded = true;
          Data.usingOverride = false;
        }
      }
    } catch (err) { console.warn('[Cine Focus] Firebase data could not be loaded; trying local files.', err); }
    if (!remoteLoaded && ov && ov.content && ov.banners && ov.sections) {
      c = ov.content; b = ov.banners; sec = ov.sections;
      platforms = ov.platforms || { platforms: [] }; settings = ov.settings || {};
      Data.usingOverride = true;
    } else if (!remoteLoaded) {
      Data.usingOverride = false;
      try {
        [c, b, sec, platforms] = await Promise.all([
          getJSON('data/content.json'), getJSON('data/banners.json'),
          getJSON('data/sections.json'), getJSON('data/platforms.json').catch(() => ({platforms:[]} ))
        ]);
      } catch (err) {
        if (window.CF_LOCAL_DATA) {
          c = window.CF_LOCAL_DATA.content; b = window.CF_LOCAL_DATA.banners; sec = window.CF_LOCAL_DATA.sections;
          platforms = { platforms: [] };
          console.info('[Cine Focus] Using embedded local-preview data.');
        } else { throw err; }
      }
    }
    // Realtime Database may return numeric-key objects instead of arrays; normalize them.
    const asArray = v => Array.isArray(v) ? v : (v && typeof v === 'object' ? Object.keys(v).sort((a,b)=>Number(a)-Number(b)).map(k=>v[k]) : []);
    if (c) c.items = asArray(c.items);
    if (b) b.banners = asArray(b.banners);
    if (platforms) platforms.platforms = asArray(platforms.platforms);
    if (sec && typeof sec === 'object') Object.keys(sec).forEach(k => { if (Array.isArray(sec[k]) || (sec[k] && typeof sec[k] === 'object' && !('rule' in sec[k]))) sec[k] = asArray(sec[k]); });
    Data.raw = { content: c || {items:[]}, banners: b || {banners:[]}, sections: sec || {home:[]}, platforms: platforms || {platforms:[]}, settings };
    Data.build();
  };

  const arr = v => Array.isArray(v) ? v.map(String).map(x => x.trim()).filter(Boolean) : (typeof v === 'string' && v ? v.split(',').map(s => s.trim()).filter(Boolean) : []);
  const num = v => (v === '' || v == null || isNaN(+v)) ? null : +v;
  const url = v => typeof v === 'string' ? v.trim() : '';

  function norm(r, idx) {
    if (!r || typeof r !== 'object') { Data.errors.push('Item #' + idx + ' is not an object'); return null; }
    const id = String(r.id || '').trim(), title = String(r.title || '').trim();
    if (!id || !title || !TYPES.includes(r.type)) { Data.errors.push('Item #' + idx + ' (' + (id || 'no id') + ') skipped: needs id, title and a valid type'); return null; }
    return Object.assign({}, r, {
      id, title, genres: arr(r.genres), tags: arr(r.tags), cast: arr(r.cast),
      poster: url(r.poster), thumbnail: url(r.thumbnail), banner: url(r.banner),
      videoUrl: url(r.videoUrl || r.watchUrl), watchUrl: url(r.watchUrl || r.videoUrl), downloadUrl: url(r.downloadUrl),
      aspectRatio: RATIOS.includes(r.aspectRatio) ? r.aspectRatio : '16:9',
      duration: num(r.duration), releaseYear: num(r.releaseYear), rating: num(r.rating), views: num(r.views),
      order: num(r.order) == null ? 9999 : num(r.order),
      seasonNumber: num(r.seasonNumber) || 1, episodeNumber: num(r.episodeNumber) || 0,
      published: r.published !== false,
      subtitles: Array.isArray(r.subtitles) ? r.subtitles.filter(s => s && s.src) : [],
      _i: idx
    });
  }

  Data.build = function () {
    const raw = Data.raw || {}; Data.errors = [];
    const list = raw.content && Array.isArray(raw.content.items) ? raw.content.items : [];
    const seen = new Set(); Data.items = []; Data.byId = {};
    list.forEach((r, i) => {
      const it = norm(r, i); if (!it) return;
      if (seen.has(it.id)) { Data.errors.push('Duplicate id ' + it.id + ' ignored'); return; }
      seen.add(it.id); Data.items.push(it); Data.byId[it.id] = it;
    });
    const bl = Array.isArray(raw.banners && raw.banners.banners) ? raw.banners.banners : [];
    Data.banners = bl.filter(b => b && b.title && b.image !== undefined).map((b, i) => ({
      id: String(b.id || 'banner_' + i), image: url(b.image), title: String(b.title), description: String(b.description || ''),
      category: String(b.category || ''), buttonText: String(b.buttonText || ''), contentId: String(b.contentId || ''),
      order: num(b.order) == null ? 9999 : num(b.order), active: b.active !== false
    })).sort((a, b) => a.order - b.order);
    if (Data.errors.length) console.warn('[Cine Focus] content warnings:\n' + Data.errors.join('\n'));
  };

  Data.sectionList = function (page) {
    const a = (Data.raw && Data.raw.sections && Array.isArray(Data.raw.sections[page])) ? Data.raw.sections[page] : [];
    return a.filter(s => s && s.id && s.visible !== false).map(s => Object.assign({}, s, { page }))
      .sort((x, y) => (num(x.order) == null ? 9999 : num(x.order)) - (num(y.order) == null ? 9999 : num(y.order)));
  };
  Data.filters = function (kind) {
    const a = Data.raw && Data.raw.sections && Data.raw.sections[kind + 'Filters'];
    return Array.isArray(a) && a.length ? a : [{ label: 'All' }];
  };

  const eq = (a, b) => String(a || '').toLowerCase() === String(b || '').toLowerCase();
  Data.matches = function (it, r) {
    if (r.genre && !it.genres.some(g => eq(g, r.genre))) return false;
    if (r.language && !eq(it.language, r.language)) return false;
    if (r.category && !eq(it.category, r.category)) return false;
    if (r.tag && !it.tags.some(g => eq(g, r.tag))) return false;
    if (r.status && !eq(it.status, r.status)) return false;
    for (const k of ['trending', 'featured', 'newArrival']) if (r[k] !== undefined && !!it[k] !== !!r[k]) return false;
    return true;
  };

  const SORTS = {
    order: (a, b) => a.order - b.order || a._i - b._i,
    latest: (a, b) => (b.releaseYear || 0) - (a.releaseYear || 0) || String(b.addedAt || '').localeCompare(String(a.addedAt || '')) || b._i - a._i,
    recent: (a, b) => String(b.addedAt || '').localeCompare(String(a.addedAt || '')) || b._i - a._i,
    popular: (a, b) => (b.views || 0) - (a.views || 0),
    title: (a, b) => a.title.localeCompare(b.title)
  };

  /* rule: {types, ids, genre, language, category, tag, status, trending, featured, newArrival, sort} */
  Data.query = function (rule, limit) {
    rule = rule && typeof rule === 'object' ? rule : {};
    let l;
    if (Array.isArray(rule.ids)) l = rule.ids.map(i => Data.byId[i]).filter(x => x && x.published);
    else {
      const types = Array.isArray(rule.types) && rule.types.length ? rule.types : ['movie', 'series', 'drama', 'video', 'short'];
      l = Data.items.filter(i => i.published && types.includes(i.type) && Data.matches(i, rule));
      l.sort(SORTS[rule.sort] || SORTS.order);
    }
    return limit ? l.slice(0, limit) : l;
  };

  Data.isEpisodic = it => !!it && (it.type === 'drama' || it.type === 'series');
  Data.episodes = function (pid) {
    return Data.items.filter(i => i.type === 'episode' && i.dramaId === pid && i.published)
      .sort((a, b) => a.seasonNumber - b.seasonNumber || a.episodeNumber - b.episodeNumber || a.order - b.order || a._i - b._i);
  };
  Data.seasons = pid => [...new Set(Data.episodes(pid).map(e => e.seasonNumber))].sort((a, b) => a - b);

  Data.related = function (it, n) {
    const t = it.type === 'episode' ? (Data.byId[it.dramaId] || it) : it;
    return Data.items.filter(i => i.published && i.type === t.type && i.id !== t.id).map(i => ({
      i, s: i.genres.filter(g => t.genres.some(x => eq(x, g))).length * 2 + (eq(i.language, t.language) ? 1 : 0)
    })).sort((a, b) => b.s - a.s || a.i._i - b.i._i).slice(0, n || 10).map(x => x.i);
  };

  Data.search = function (q, limit) {
    q = String(q || '').trim().toLowerCase(); if (!q) return [];
    const out = [];
    Data.items.forEach(it => {
      if (!it.published) return;
      if (it.type === 'episode') { const p = Data.byId[it.dramaId]; if (!p || !p.published) return; }
      const t = it.title.toLowerCase(), alt = String(it.altTitle || '').toLowerCase();
      let s = 0;
      if (t.startsWith(q)) s = 100; else if (t.includes(q)) s = 80; else if (alt.includes(q)) s = 70;
      else if (it.genres.some(g => g.toLowerCase().includes(q)) || String(it.language || '').toLowerCase().includes(q) || it.tags.some(g => g.toLowerCase().includes(q))) s = 40;
      else if (String(it.description || '').toLowerCase().includes(q)) s = 20;
      if (it.type === 'episode' && !s) { const p = Data.byId[it.dramaId]; if (p.title.toLowerCase().includes(q)) s = 30; }
      if (s) out.push({ it, s });
    });
    out.sort((a, b) => b.s - a.s || a.it._i - b.it._i);
    return out.slice(0, limit || 40).map(x => x.it);
  };
})();
