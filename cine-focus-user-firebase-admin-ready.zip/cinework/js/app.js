/* Cine Focus – bootstrap, hash router and global event handling. */
(function () {
  'use strict';
  const CF = window.CF;
  const { $, $$, esc, icon, Store, Data } = CF;

  const NAV = [['home', 'Home', 'home'], ['videos', 'Videos', 'video'], ['drama', 'Drama', 'mask'], ['downloads', 'Downloads', 'download'], ['profile', 'Profile', 'user']];
  const TOP = new Set(['home', 'videos', 'drama', 'downloads', 'profile']);
  const leave = []; CF.onLeave = f => leave.push(f);
  const scrolls = {}; let lastKey = null, navCount = 0;

  function parse() {
    const h = location.hash.slice(1) || '/home', i = h.indexOf('?');
    const path = i < 0 ? h : h.slice(0, i);
    return { key: h, parts: path.split('/').filter(Boolean).map(p => { try { return decodeURIComponent(p); } catch (e) { return p; } }), q: new URLSearchParams(i < 0 ? '' : h.slice(i + 1)) };
  }
  function activeNav(name, args) {
    let id = name;
    if (name === 'title' || name === 'watch') {
      const it = Data.byId[args[0]]; const t = it && (it.type === 'episode' ? 'drama' : it.type);
      id = t === 'video' ? 'videos' : (t === 'drama' || t === 'series') ? 'drama' : 'home';
    } else if (!TOP.has(name)) id = ['watchlist', 'favorites', 'history', 'continue', 'settings', 'help', 'about'].includes(name) ? 'profile' : 'home';
    $$('[data-nav]').forEach(a => { const on = a.dataset.nav === id; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  }

  CF.render = function (keep) {
    const r = parse(), view = $('#view');
    if (lastKey !== null) scrolls[lastKey] = window.scrollY;
    leave.splice(0).forEach(f => { try { f(); } catch (e) { /* ignore */ } });
    CF.closeModal();
    const [name, ...args] = r.parts;
    const fn = CF.views[name || 'home'];
    let out;
    try { out = fn ? fn(args, r.q) : { html: `<div class="page">${CF.empty('Page not found', 'That address does not exist.')}<p class="center"><a class="btn primary" href="#/home">Go Home</a></p></div>` }; }
    catch (err) { console.error(err); out = { html: `<div class="page"><div class="empty err"><div class="empty-ic">${icon('info')}</div><h3>Something went wrong</h3><p>This page could not be displayed. The rest of the app still works.</p><p class="center"><a class="btn primary" href="#/home">Go Home</a></p></div></div>` }; }
    view.innerHTML = out.html;
    try { if (out.mount) out.mount(view); } catch (err) { console.error(err); }
    document.title = (out.title ? out.title + ' – ' : '') + 'Cine Focus';
    activeNav(name || 'home', args);
    const y = (keep || TOP.has(name)) && scrolls[r.key] != null ? scrolls[r.key] : 0;
    window.scrollTo(0, y);
    lastKey = r.key;
  };
  window.addEventListener('hashchange', () => { navCount++; CF.render(); });

  function buildNav() {
    const h = NAV.map(([id, l, ic]) => `<a class="nav-i" data-nav="${id}" href="#/${id}">${icon(ic)}<span>${l}</span></a>`).join('');
    $('#bnav').innerHTML = h; $('#snav').innerHTML = h;
  }
  function applyTheme() {
    const t = Store.settings().theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = t; document.querySelector('meta[name=theme-color]').content = t === 'dark' ? '#030817' : '#EEF3FB';
  }

  document.addEventListener('click', e => {
    const el = e.target.closest('[data-action]'); if (!el) return;
    const f = CF.actions[el.dataset.action]; if (!f) return;
    if (el.tagName === 'A') e.preventDefault();
    f(el, e);
  });
  document.addEventListener('change', e => { const el = e.target.closest('[data-change]'); if (el && CF.changes[el.dataset.change]) CF.changes[el.dataset.change](el, e); });
  document.addEventListener('input', e => { const el = e.target.closest('[data-change="afilter"]'); if (el && CF.changes.afilter) CF.changes.afilter(el, e); });

  CF.actions.back = () => { if (navCount > 0) history.back(); else location.hash = '#/home'; };
  CF.actions.sidebar = () => { const a = $('#app'); a.classList.toggle('collapsed'); Store.set('sidebar', a.classList.contains('collapsed')); };
  CF.actions.reload = () => location.reload();
  CF.actions.resetoverride = () => { Store.del('override'); location.reload(); };

  window.addEventListener('offline', () => CF.toast('You are offline. Saved titles may still play; streaming needs a connection.'));
  window.addEventListener('online', () => CF.toast('Back online.'));

  (async function boot() {
    applyTheme(); buildNav();
    if (Store.get('sidebar', false)) $('#app').classList.add('collapsed');
    if (!Store.persistent) setTimeout(() => CF.toast('Browser storage is blocked – progress and lists will not be saved.'), 800);
    try { await Data.load(); }
    catch (e) {
      console.error(e);
      $('#view').innerHTML = `<div class="page"><div class="empty err"><div class="empty-ic">${icon('info')}</div><h3>Couldn't load the content files</h3><p>${esc(e.message)}</p><p>Cine Focus reads its <code>data/*.json</code> files with fetch(), so it must be served over HTTP, not opened as a <code>file://</code> page. Run <code>python3 -m http.server 8080</code> in the project folder and open <code>http://localhost:8080</code>.</p><p class="center"><button class="btn primary" data-action="reload">Try again</button> <button class="btn ghost" data-action="resetoverride">Reset local content edits</button></p></div></div>`;
      return;
    }
    CF.Downloads.init();
    CF.render();
  })();
})();
