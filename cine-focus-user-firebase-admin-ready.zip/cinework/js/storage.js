/* Cine Focus – browser-side storage (LocalStorage + IndexedDB).
   Everything is local to this browser. Falls back to memory if storage is blocked. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const P = 'cf_', mem = {};
  let ok = true;
  try { localStorage.setItem(P + '_t', '1'); localStorage.removeItem(P + '_t'); } catch (e) { ok = false; }

  const Store = CF.Store = {
    persistent: ok,
    get(k, d) { try { const v = ok ? localStorage.getItem(P + k) : mem[P + k]; return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) {
      const s = JSON.stringify(v);
      try { if (ok) localStorage.setItem(P + k, s); else mem[P + k] = s; return true; }
      catch (e) { mem[P + k] = s; return false; }
    },
    del(k) { try { if (ok) localStorage.removeItem(P + k); } catch (e) {} delete mem[P + k]; },
    clearAll() {
      try { if (ok) Object.keys(localStorage).filter(k => k.startsWith(P)).forEach(k => localStorage.removeItem(k)); } catch (e) {}
      Object.keys(mem).forEach(k => delete mem[k]);
    },
    settings() { return Object.assign({ theme: 'dark', autoplay: true, speed: 1, subtitles: false }, this.get('settings', {})); },
    setSetting(k, v) { const s = this.settings(); s[k] = v; this.set('settings', s); },
    profile() { return Object.assign({ name: 'Guest', username: 'guest', avatar: '' }, this.get('profile', {})); },
    list(n) { const l = this.get(n, []); return Array.isArray(l) ? l : []; },
    has(n, id) { return this.list(n).some(x => x.id === id); },
    toggle(n, id) {
      let l = this.list(n); const had = l.some(x => x.id === id);
      l = had ? l.filter(x => x.id !== id) : [{ id, ts: Date.now() }, ...l];
      this.set(n, l); return !had;
    },
    progressAll() { const p = this.get('progress', {}); return p && typeof p === 'object' ? p : {}; },
    progress(id) { return this.progressAll()[id] || null; },
    saveProgress(id, parentId, pos, dur, done) {
      const a = this.progressAll();
      a[id] = { id, parentId: parentId || null, pos: Math.floor(pos || 0), dur: Math.floor(dur || 0), ts: Date.now(), done: !!done };
      this.set('progress', a);
    },
    removeProgress(id) { const a = this.progressAll(); delete a[id]; this.set('progress', a); }
  };

  const IDB = CF.IDB = {
    db: null,
    open() {
      return new Promise((res, rej) => {
        if (!window.indexedDB) return rej(new Error('IndexedDB is not available in this browser.'));
        if (this.db) return res(this.db);
        const r = indexedDB.open('cinefocus', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('files');
        r.onsuccess = () => { this.db = r.result; res(this.db); };
        r.onerror = () => rej(r.error || new Error('IndexedDB failed to open.'));
      });
    },
    async tx(mode, fn) {
      const db = await this.open();
      return new Promise((res, rej) => {
        const t = db.transaction('files', mode); const rq = fn(t.objectStore('files'));
        t.oncomplete = () => res(rq ? rq.result : undefined);
        t.onerror = t.onabort = () => rej(t.error || new Error('IndexedDB transaction failed'));
      });
    },
    put(k, v) { return this.tx('readwrite', s => s.put(v, k)); },
    get(k) { return this.tx('readonly', s => s.get(k)); },
    del(k) { return this.tx('readwrite', s => s.delete(k)); },
    clear() { return this.tx('readwrite', s => s.clear()); }
  };
})();
