/* Cine Focus – shared UI helpers and card components. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const enc = encodeURIComponent;
  Object.assign(CF, { $, $$, esc, enc, views: {}, actions: {}, changes: {}, state: { vf: 0, df: 0, adminTab: 'content', adminPage: 'home', dlTab: 'done', dlType: 'all', autoStart: false } });
  const { Store } = CF;

  CF.icon = (n, c = '') => `<svg class="ic ${c}" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;
  const icon = CF.icon;
  CF.fmtTime = s => { s = Math.max(0, Math.floor(+s || 0)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = String(s % 60).padStart(2, '0'); return h ? `${h}:${String(m).padStart(2, '0')}:${x}` : `${m}:${x}`; };
  CF.fmtViews = n => n == null ? '' : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K' : String(n);
  CF.fmtSize = b => !b ? '' : b >= 1e9 ? (b / 1e9).toFixed(2) + ' GB' : b >= 1e6 ? Math.round(b / 1e6) + ' MB' : Math.ceil(b / 1e3) + ' KB';
  CF.fmtDate = ts => new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  CF.label = { movie: 'Movie', series: 'Series', drama: 'Drama', episode: 'Episode', video: 'Video', short: 'Short Film' };

  /* ---------- images with generated fallbacks ---------- */
  const hue = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  CF.art = (title, ratio) => {
    const [w, h] = ratio === '16:9' ? [320, 180] : ratio === '9:16' ? [180, 320] : ratio === '1:1' ? [240, 240] : [240, 320];
    const a = hue(title), b = (a + 70) % 360;
    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${w} ${h}'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='hsl(${a} 70% 36%)'/><stop offset='1' stop-color='hsl(${b} 75% 14%)'/></linearGradient></defs><rect width='100%' height='100%' fill='url(#g)'/><circle cx='${w * .8}' cy='${h * .2}' r='${w * .22}' fill='white' fill-opacity='.07'/><text x='50%' y='54%' fill='white' fill-opacity='.9' font-family='sans-serif' font-weight='700' font-size='${Math.round(w / 11)}' text-anchor='middle'>${esc(String(title).slice(0, 20))}</text></svg>`;
    return 'data:image/svg+xml,' + encodeURIComponent(svg);
  };
  CF.img = (src, title, ratio, cls, loading) =>
    `<img ${cls ? `class="${cls}" ` : ''}src="${esc(src || CF.art(title, ratio))}" alt="${esc(title)}" loading="${loading || 'lazy'}" decoding="async" draggable="false" data-t="${esc(title)}" data-r="${esc(ratio)}">`;
  document.addEventListener('error', e => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.fb) { t.dataset.fb = '1'; t.src = CF.art(t.dataset.t || 'Cine Focus', t.dataset.r || '3:4'); }
  }, true);

  /* ---------- content helpers ---------- */
  CF.href = it => it.type === 'video' || it.type === 'episode' ? '#/watch/' + enc(it.id) : '#/title/' + enc(it.id);
  CF.thumbOf = it => {
    let s = it.thumbnail || it.banner || it.poster;
    if (!s && it.type === 'episode') { const p = CF.Data.byId[it.dramaId]; if (p) s = p.thumbnail || p.banner || p.poster; }
    return s || '';
  };
  CF.posterOf = it => it.poster || it.thumbnail || it.banner || '';

  CF.posterCard = it => {
    const eps = CF.Data.isEpisodic(it) ? CF.Data.episodes(it.id).length : 0;
    const meta = [CF.label[it.type], it.language, it.releaseYear].filter(Boolean).join(' · ');
    return `<article class="pcard"><a class="pcard-main" href="#/title/${enc(it.id)}"><div class="poster">${CF.img(CF.posterOf(it), it.title, '3:4')}${it.newArrival ? '<span class="badge new">NEW</span>' : ''}${eps ? `<span class="badge eps">${eps} ep</span>` : ''}<span class="poster-play">${icon('play')}</span></div><div class="pt">${esc(it.title)}</div><div class="pm">${esc(meta)}${it.rating ? ' · ★ ' + esc(it.rating) : ''}</div></a></article>`;
  };
  CF.videoCard = it => {
    const par = it.type === 'episode' ? CF.Data.byId[it.dramaId] : null;
    const title = par ? `${par.title} · E${it.episodeNumber}` : it.title;
    const meta = it.type === 'episode' ? `Season ${it.seasonNumber}` : [it.category || it.genres[0], it.views != null ? CF.fmtViews(it.views) + ' views' : ''].filter(Boolean).join(' · ');
    return `<article class="vcard"><a class="vcard-main" href="#/title/${enc(it.id)}"><div class="thumb">${CF.img(CF.thumbOf(it), title, '16:9')}<span class="play-ov">${icon('play')}</span></div><div class="pt">${esc(title)}</div><div class="pm">${esc(meta)}</div></a></article>`;
  };
  CF.contCard = (it, p) => {
    const par = it.type === 'episode' ? CF.Data.byId[it.dramaId] : null;
    const title = par ? par.title : it.title;
    const sub = it.type === 'episode' ? `S${it.seasonNumber} · E${it.episodeNumber}` : CF.label[it.type];
    const pct = p.dur ? Math.min(1, p.pos / p.dur) : 0;
    return `<a class="ccard" href="#/watch/${enc(it.id)}"><div class="thumb">${CF.img(CF.thumbOf(it), title, '16:9')}<span class="play-ov">${icon('play')}</span><div class="pbar"><i style="width:${(pct * 100).toFixed(1)}%"></i></div></div><div class="pt">${esc(title)}</div><div class="pm">${esc(sub)} · ${CF.fmtTime(p.pos)} watched</div></a>`;
  };
  CF.mixedGrid = (items, rm) => {
    const wrap = (it, card) => rm ? `<div class="cwrap">${card}<button class="rm" data-action="unlist" data-list="${rm}" data-id="${esc(it.id)}" aria-label="Remove ${esc(it.title)}">${icon('close')}</button></div>` : card;
    const p = items.filter(i => i.type !== 'video' && i.type !== 'episode'), v = items.filter(i => i.type === 'video' || i.type === 'episode');
    return (p.length ? `<div class="grid-p">${p.map(i => wrap(i, CF.posterCard(i))).join('')}</div>` : '') + (v.length ? `<div class="grid-v">${v.map(i => wrap(i, CF.videoCard(i))).join('')}</div>` : '');
  };

  const TOG = { wl: { list: 'watchlist', icon: 'bookmark', on: 'In Watchlist', off: 'Add to Watchlist' }, fav: { list: 'favorites', icon: 'heart', on: 'Favorited', off: 'Add to Favorites' } };
  CF.toggleBtn = (kind, id, label = true) => {
    const t = TOG[kind], on = Store.has(t.list, id);
    return `<button class="btn ghost tog ${on ? 'on' : ''}" data-action="${kind}" data-id="${esc(id)}" aria-pressed="${on}" aria-label="${on ? t.on : t.off}">${icon(t.icon)}${label ? `<span>${on ? t.on : t.off}</span>` : ''}</button>`;
  };
  CF.refreshToggles = () => $$('[data-action=wl],[data-action=fav]').forEach(b => {
    const t = TOG[b.dataset.action], on = Store.has(t.list, b.dataset.id);
    b.classList.toggle('on', on); b.setAttribute('aria-pressed', on); b.setAttribute('aria-label', on ? t.on : t.off);
    const s = $('span', b); if (s) s.textContent = on ? t.on : t.off;
  });
  CF.avatarHTML = () => {
    const p = Store.profile();
    return p.avatar ? `<img class="avatar" src="${esc(p.avatar)}" alt="" data-t="${esc(p.name)}" data-r="1:1">` : `<span class="avatar" aria-hidden="true">${esc((p.name || 'G').trim().charAt(0).toUpperCase() || 'G')}</span>`;
  };

  /* ---------- toast & dialogs ---------- */
  CF.toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(CF._tt); CF._tt = setTimeout(() => t.classList.remove('show'), 2800); };
  CF.modal = html => { const d = $('#modal'); d.onclose = null; d.returnValue = ''; d.innerHTML = html; if (!d.open) d.showModal(); return d; };
  CF.closeModal = () => { const d = $('#modal'); if (d.open) d.close(); };
  CF.confirm = (msg, okLabel) => new Promise(res => {
    const d = CF.modal(`<form method="dialog" class="dlg" role="alertdialog" aria-label="Confirm"><p>${esc(msg)}</p><div class="dlg-actions"><button value="no" class="btn ghost">Cancel</button><button value="yes" class="btn primary" autofocus>${esc(okLabel || 'Confirm')}</button></div></form>`);
    d.onclose = () => res(d.returnValue === 'yes');
  });
  document.addEventListener('click', e => { const d = $('#modal'); if (e.target === d && d.open) d.close(); });
})();
