/* Cine Focus – views: Home, Videos, Drama, detail, watch, search, lists. */
(function () {
  'use strict';
  const CF = window.CF = window.CF || {};
  const { $, $$, esc, enc, icon, Data, Store } = CF;
  const V = CF.views, A = CF.actions, CH = CF.changes;

  const searchBtn = `<a class="iconbtn" href="#/search" aria-label="Search">${icon('search')}</a>`;
  CF.hdr = (title, o) => {
    o = o || {};
    return `<header class="hdr">${o.back ? `<button class="iconbtn" data-action="back" aria-label="Go back">${icon('back')}</button>` : ''}${o.logo ? `<a class="logo" href="#/home"><img src="assets/logos/logo.svg" alt="" width="32" height="32"><span>${esc((Data.raw && Data.raw.settings && Data.raw.settings.siteName) || "Cine Focus")}</span></a>` : `<h1>${esc(title)}</h1>`}<span class="sp"></span>${o.right === undefined ? searchBtn : o.right}</header>`;
  };
  const hdr = CF.hdr;
  CF.empty = (t, s) => `<div class="empty"><div class="empty-ic">${icon('film')}</div><h3>${esc(t)}</h3>${s ? `<p>${esc(s)}</p>` : ''}</div>`;
  const empty = CF.empty;
  const notFound = () => ({ html: `${hdr('Not found', { back: 1, right: '' })}<div class="page">${empty('Content not found', 'It may have been removed or unpublished.')}<p class="center"><a class="btn primary" href="#/home">Go Home</a></p></div>` });

  /* ---------- sections (data-driven) ---------- */
  function continueItems(limit) {
    return Object.values(Store.progressAll()).filter(p => p && !p.done && p.pos > 5 && Data.byId[p.id] && Data.byId[p.id].published)
      .sort((a, b) => b.ts - a.ts).slice(0, limit || 12).map(p => ({ it: Data.byId[p.id], p }));
  }
  const secHead = s => {
    const href = typeof s.seeAll === 'string' ? s.seeAll : s.type === 'continue' ? '#/continue' : `#/list/section/${enc(s.page + ':' + s.id)}`;
    return `<div class="sec-head"><div><h2>${s.icon ? `<span aria-hidden="true">${esc(s.icon)}</span> ` : ''}${esc(s.title)}</h2>${s.subtitle ? `<p>${esc(s.subtitle)}</p>` : ''}</div>${s.seeAll === false ? '' : `<a class="seeall" href="${esc(href)}" aria-label="See all ${esc(s.title)}">See All ${icon('chev')}</a>`}</div>`;
  };
  CF.sectionHTML = s => {
    if (s.type === 'continue') {
      const c = continueItems(s.limit); if (!c.length) return '';
      return `<section class="sec">${secHead(s)}<div class="row">${c.map(x => CF.contCard(x.it, x.p)).join('')}</div></section>`;
    }
    const items = Data.query(s.rule, s.limit || 12);
    if (!items.length) return s.showEmpty ? `<section class="sec">${secHead(s)}<p class="empty-s">Nothing here yet.</p></section>` : '';
    const vid = s.card === 'video' || (s.card !== 'poster' && items.every(i => i.type === 'video'));
    const card = vid ? CF.videoCard : CF.posterCard;
    const body = s.layout === 'grid' ? `<div class="${vid ? 'grid-v' : 'grid-p'}">${items.map(card).join('')}</div>` : `<div class="row">${items.map(card).join('')}</div>`;
    return `<section class="sec">${secHead(s)}${body}</section>`;
  };
  const sectionsHTML = page => Data.sectionList(page).map(CF.sectionHTML).join('');

  /* ---------- banner carousel ---------- */
  function bannerHTML(bs) {
    if (!bs.length) return '';
    const slides = bs.map((b, i) => {
      const t = b.contentId && Data.byId[b.contentId], href = t && t.published ? CF.href(t) : '';
      return `<div class="slide" role="group" aria-roledescription="slide" aria-label="${i + 1} of ${bs.length}"${href ? ` data-href="${esc(href)}"` : ''}>${CF.img(b.image || CF.art(' ', '16:9'), b.title, '16:9', '', i === 0 ? 'eager' : 'lazy')}<div class="slide-ov">${b.category ? `<span class="kicker">${esc(b.category)}</span>` : ''}<h2>${esc(b.title)}</h2>${b.description ? `<p>${esc(b.description)}</p>` : ''}${href ? `<a class="btn primary sm" href="${esc(href)}">${icon('play')}${esc(b.buttonText || 'Watch Now')}</a>` : ''}</div></div>`;
    }).join('');
    const multi = bs.length > 1;
    return `<section class="banner" aria-roledescription="carousel" aria-label="Featured"><div class="slides">${slides}</div>${multi ? `<button class="bn-btn prev" data-bn="-1" aria-label="Previous slide">${icon('back')}</button><button class="bn-btn next" data-bn="1" aria-label="Next slide">${icon('chev')}</button><div class="dots">${bs.map((_, i) => `<button data-dot="${i}" aria-label="Go to slide ${i + 1}"></button>`).join('')}</div>` : ''}</section>`;
  }

  CF.carousel = function (root) {
    const track = $('.slides', root), slides = $$('.slide', root), n = slides.length, dots = $$('[data-dot]', root);
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    let i = 0, dx = 0, sx = 0, drag = false, moved = false, hover = false, holdUntil = 0, visible = true, timer = null;
    function go(k, user) {
      i = (k + n) % n; track.style.transition = ''; track.style.transform = `translateX(${-((slides[i] && slides[i].offsetLeft) || 0)}px)`;
      dots.forEach((d, j) => { d.classList.toggle('on', j === i); d.setAttribute('aria-current', j === i ? 'true' : 'false'); });
      if (user) holdUntil = Date.now() + 8000;
    }
    go(0);
    if (n < 2) return { destroy() {} };
    if (!reduce) timer = setInterval(() => { if (!hover && visible && !document.hidden && Date.now() > holdUntil && !drag) go(i + 1); }, 3000);
    root.addEventListener('mouseenter', () => { hover = true; }); root.addEventListener('mouseleave', () => { hover = false; });
    root.addEventListener('pointerdown', e => { if (e.target.closest('button,a')) return; sx = e.clientX; dx = 0; drag = true; moved = false; track.style.transition = 'none'; });
    root.addEventListener('pointermove', e => { if (!drag) return; dx = e.clientX - sx; if (Math.abs(dx) > 6) moved = true; track.style.transform = `translateX(calc(${-((slides[i] && slides[i].offsetLeft) || 0)}px + ${dx}px))`; });
    const end = () => { if (!drag) return; drag = false; if (Math.abs(dx) > root.clientWidth * .15) go(i + (dx < 0 ? 1 : -1), true); else go(i, true); };
    root.addEventListener('pointerup', end); root.addEventListener('pointercancel', end); root.addEventListener('pointerleave', end);
    root.addEventListener('click', e => {
      const b = e.target.closest('[data-bn]'), d = e.target.closest('[data-dot]');
      if (b) return go(i + +b.dataset.bn, true);
      if (d) return go(+d.dataset.dot, true);
      if (moved) { moved = false; return; }
      const s = e.target.closest('.slide[data-href]'); if (s && !e.target.closest('a,button')) location.hash = s.dataset.href;
    });
    root.addEventListener('keydown', e => { if (e.key === 'ArrowRight') go(i + 1, true); else if (e.key === 'ArrowLeft') go(i - 1, true); });
    root.addEventListener('focusin', () => { holdUntil = Date.now() + 8000; });
    let io; if ('IntersectionObserver' in window) { io = new IntersectionObserver(en => { visible = en[0].isIntersecting; }); io.observe(root); }
    return { destroy() { clearInterval(timer); if (io) io.disconnect(); } };
  };

  /* ---------- HOME ---------- */
  V.home = () => {
    const topics = (Data.raw.platforms && Array.isArray(Data.raw.platforms.platforms) ? Data.raw.platforms.platforms : []).filter(p=>p && p.active !== false && p.name).sort((a,b)=>(+a.order||9999)-(+b.order||9999)).map(p=>[p.name,p.url || '#/drama']);
    const secs = sectionsHTML('home');
    const searchHeader = `<header class="home-search"><a class="home-mark" href="#/home" aria-label="${esc((Data.raw && Data.raw.settings && Data.raw.settings.siteName) || "Cine Focus")} Home"><img src="assets/logos/logo.svg" alt=""></a><a class="home-searchbox" href="#/search">${icon('search')}<span>Search Movie/Series/Audio</span><b>Search</b></a><a class="avatar-sm" href="#/profile" aria-label="Profile">${CF.avatarHTML()}</a></header>`;
    return {
      title: 'Cine Focus',
      html: `${searchHeader}<nav class="topic-nav" aria-label="Explore categories">${topics.map((t,i) => `<a class="topic-link ${i===1?'active':''}" href="${t[1]}">${t[0]}</a>`).join('')}</nav><div class="page home-page">${bannerHTML(Data.banners.filter(b => b.active))}<div class="home-feature-row">${Data.query({featured:true}, 5).slice(0,5).map(it => `<a class="feature-mini" href="${CF.href(it)}">${CF.img(CF.thumbOf(it), it.title, '3:4')}<span>${esc(it.title)}</span><b aria-hidden="true">${icon('play')}</b></a>`).join('')}</div>${secs || empty('No content yet', 'New titles will appear here when the catalogue is published.')}</div>`,
      mount(v) { const b = $('.banner', v); if (b) CF.onLeave(CF.carousel(b).destroy); }
    };
  };

  /* ---------- VIDEOS ---------- */
  function videosBody(fi) {
    const f = Data.filters('video')[fi] || { label: 'All' };
    if (!f.rule) return sectionsHTML('videos') || empty('No videos yet', 'New videos will appear here when the catalogue is published.');
    const items = Data.query(Object.assign({ types: ['video'] }, f.rule));
    return items.length ? `<div class="grid-v">${items.map(CF.videoCard).join('')}</div>` : empty('No videos match this filter');
  }
  const chipsHTML = (list, cur, act) => `<div class="chips" role="tablist">${list.map((f, i) => `<button class="chip ${i === cur ? 'on' : ''}" role="tab" aria-selected="${i === cur}" data-action="${act}" data-i="${i}">${esc(f.label)}</button>`).join('')}</div>`;
  V.videos = () => {
    /* Videos page starts with the actual video thumbnail feed, not a single trailer hero. */
    const hero = bannerHTML(Data.banners.filter(b => b.active));
    return { title: 'Videos', html: `${hdr('Videos')}<div class="page video-page">${hero}${chipsHTML(Data.filters('video'), CF.state.vf, 'vf')}<div id="vbody">${videosBody(CF.state.vf)}</div></div>`, mount(v) { const b = $('.banner', v); if (b) CF.onLeave(CF.carousel(b).destroy); } };
  };
  A.vf = el => { CF.state.vf = +el.dataset.i; $$('[data-action=vf]').forEach(b => { const on = b === el; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); }); $('#vbody').innerHTML = videosBody(CF.state.vf); };

  /* ---------- DRAMA ---------- */
  function dramaBody(fi) {
    const f = Data.filters('drama')[fi] || { label: 'All' };
    if (!f.rule) return sectionsHTML('drama') || empty('No dramas yet', 'Dramas and episodes will appear here when the catalogue is published.');
    const items = Data.query(Object.assign({ types: ['drama'] }, f.rule));
    return items.length ? `<div class="grid-p">${items.map(CF.posterCard).join('')}</div>` : empty('No dramas match this filter');
  }
  V.drama = () => {
    const featured = Data.query({ types: ['drama'] }).filter(x => x.featured).slice(0, 10);
    const posterItems = Data.query({ types: ['drama'] }).filter(x => x.published);
    const posterRail = posterItems.length ? `<section class="drama-poster-rail layered-rail" aria-label="Featured dramas"><div class="drama-poster-track layered-track">${posterItems.map((it,i) => `<article class="drama-poster-item layered-item" data-poster-index="${i}"><a class="layered-art" href="#/title/${enc(it.id)}" aria-label="View ${esc(it.title)} details">${CF.img(CF.posterOf(it), it.title, '3:4')}<span class="drama-poster-play">${icon('play')}</span></a><b>${esc(it.title)}</b></article>`).join('')}</div></section>` : '';
    return { title: 'Drama', html: `${hdr('Drama')}<div class="page drama-page">${posterRail}${chipsHTML(Data.filters('drama'), CF.state.df, 'df')}<div id="dbody">${dramaBody(CF.state.df)}</div></div>`, mount(v) { const track = $('.drama-poster-track', v); if (!track || track.children.length < 2) return; let timer, paused=false; const cards=Array.from(track.children); let active=0; const center=(i,behavior='smooth')=>{const c=cards[(i+cards.length)%cards.length]; track.scrollTo({left:c.offsetLeft-(track.clientWidth-c.offsetWidth)/2,behavior});}; const update=()=>{const mid=track.scrollLeft+track.clientWidth/2;let best=0,dist=Infinity;cards.forEach((c,i)=>{const d=Math.abs(c.offsetLeft+c.offsetWidth/2-mid);if(d<dist){dist=d;best=i;}});active=best;cards.forEach((c,i)=>c.classList.toggle('is-center',i===active));}; track.addEventListener('scroll',update,{passive:true}); const start=()=>{clearInterval(timer);timer=setInterval(()=>{if(!paused&&!document.hidden)center(active+1);},3000);}; track.addEventListener('pointerdown',()=>{paused=true;clearInterval(timer);}); track.addEventListener('pointerup',()=>{paused=false;start();}); track.addEventListener('touchend',()=>{paused=false;start();},{passive:true}); requestAnimationFrame(()=>{center(0,'auto');update();start();}); CF.onLeave(()=>clearInterval(timer)); } };
  };
  A.df = el => { CF.state.df = +el.dataset.i; $$('[data-action=df]').forEach(b => { const on = b === el; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); }); $('#dbody').innerHTML = dramaBody(CF.state.df); };

  /* ---------- LIST (see all) & CATEGORY ---------- */
  function listPage(title, items) {
    CF._list = items;
    const gs = [...new Set(items.flatMap(i => i.genres))].sort();
    const chips = gs.length > 1 ? `<div class="chips"><button class="chip on" data-action="lg" data-g="">All</button>${gs.map(g => `<button class="chip" data-action="lg" data-g="${esc(g)}">${esc(g)}</button>`).join('')}</div>` : '';
    return { title, html: `${hdr(title, { back: 1 })}<div class="page">${chips}<div id="lbody">${items.length ? CF.mixedGrid(items) : empty('Nothing here yet')}</div></div>` };
  }
  A.lg = el => {
    $$('[data-action=lg]').forEach(b => b.classList.toggle('on', b === el));
    const g = el.dataset.g, l = (CF._list || []).filter(i => !g || i.genres.includes(g));
    $('#lbody').innerHTML = l.length ? CF.mixedGrid(l) : empty('No titles in this genre');
  };
  V.list = ([kind, key]) => {
    const [page, id] = String(key || '').split(':');
    const s = Data.sectionList(page).find(x => x.id === id) || ((Data.raw.sections[page] || []).find(x => x && x.id === id));
    if (!s) return notFound();
    if (s.type === 'continue') { location.replace('#/continue'); return { html: '' }; }
    return listPage(s.title, Data.query(s.rule));
  };
  V.cat = ([type]) => {
    const names = { movie: 'Movies', series: 'TV Series', short: 'Short Films', drama: 'Dramas', video: 'Videos' };
    if (!names[type]) return notFound();
    return listPage(names[type], Data.query({ types: [type] }));
  };

  /* ---------- DETAIL (movie / short / series / drama) ---------- */
  function primaryAction(it) {
    if (Data.isEpisodic(it)) {
      const eps = Data.episodes(it.id); if (!eps.length) return null;
      const prog = Store.progressAll(); let last = null;
      eps.forEach(e => { const p = prog[e.id]; if (p && (!last || p.ts > last.p.ts)) last = { e, p }; });
      const tag = e => `S${e.seasonNumber} E${e.episodeNumber}`;
      if (!last) return { href: '#/watch/' + enc(eps[0].id), label: 'Watch Now' };
      if (!last.p.done) return { href: '#/watch/' + enc(last.e.id), label: 'Continue ' + tag(last.e) };
      const nx = eps[eps.indexOf(last.e) + 1];
      return nx ? { href: '#/watch/' + enc(nx.id), label: 'Next: ' + tag(nx) } : { href: '#/watch/' + enc(eps[0].id), label: 'Watch Again' };
    }
    const p = Store.progress(it.id);
    return { href: '#/watch/' + enc(it.id), label: p && !p.done && p.pos > 10 ? 'Resume Watching' : 'Watch Now' };
  }
  function epRows(eps, cur) {
    if (!eps.length) return empty('No episodes yet', 'Episodes for this season have not been added.');
    return eps.map(e => {
      const p = Store.progress(e.id), pct = p && p.dur ? Math.min(1, p.pos / p.dur) : 0;
      const stt = p && p.done ? `${icon('check')} Watched` : pct ? 'In progress' : 'Unwatched';
      return `<div class="ep ${e.id === cur ? 'cur' : ''}"><a class="ep-main" href="#/watch/${enc(e.id)}" aria-label="Play Episode ${esc(e.episodeNumber)}"><div class="thumb">${CF.img(CF.thumbOf(e), 'Episode ' + e.episodeNumber, '16:9')}${pct ? `<div class="pbar"><i style="width:${(pct * 100).toFixed(1)}%"></i></div>` : ''}</div><div class="ep-t"><b>Episode ${esc(e.episodeNumber)}</b><span>${esc(e.title)}</span>${e.releaseDate ? `<small>${esc(e.releaseDate)}</small>` : ''}<small>${stt}</small></div><span class="ep-play" aria-hidden="true">${icon('play')}</span></a><button class="btn ep-download ${e.downloadUrl ? '' : 'no-file'}" data-action="dl" data-id="${esc(e.id)}" aria-label="Download Episode ${esc(e.episodeNumber)}">${icon('download')}<span>Download</span></button></div>`;
    }).join('');
  }
  const seasonSel = (pid, cur, seasons) => seasons.length > 1 ? `<label class="sr" for="seasonSel">Season</label><select class="sel" id="seasonSel" data-change="season" data-pid="${esc(pid)}" data-cur="${esc(cur || '')}">${seasons.map(s => `<option value="${s}">Season ${s}</option>`).join('')}</select>` : '';
  CH.season = el => { const box = $('#eps'); if (box) box.innerHTML = epRows(Data.episodes(el.dataset.pid).filter(e => e.seasonNumber === +el.value), el.dataset.cur); };
  A.tab = el => { $$('[data-action=tab]').forEach(b => { const on = b === el; b.classList.toggle('on', on); b.setAttribute('aria-selected', on); }); $$('.tabpanel').forEach(p => { p.hidden = p.id !== el.dataset.target; }); };

  function infoBlock(it) {
    const kv = [['Language', it.language], ['Release year', it.releaseYear], ['Genre', it.genres.join(', ')], ['Country', it.country], ['Status', it.status ? it.status.charAt(0).toUpperCase() + it.status.slice(1) : '']].filter(x => x[1]);
    return `${it.description ? `<p class="desc">${esc(it.description)}</p>` : ''}${kv.length ? `<div class="kv">${kv.map(x => `<b>${x[0]}</b><span>${esc(x[1])}</span>`).join('')}</div>` : ''}${it.cast.length ? `<h3 class="h3">Cast</h3><div class="cast">${it.cast.map(c => `<div class="cast-i"><span>${esc(c.charAt(0))}</span>${esc(c)}</div>`).join('')}</div>` : ''}${it.sample ? '<p class="demo-note">Preview title</p>' : ''}`;
  }
  function relatedBlock(it) {
    const r = Data.related(it, 12); if (!r.length) return '';
    return `<h3 class="h3">Related ${esc((CF.label[it.type] || 'titles'))}${it.type === 'series' ? '' : 's'}</h3><div class="row">${r.map(CF.posterCard).join('')}</div>`;
  }

  V.title = ([id]) => {
    const it = Data.byId[id]; if (!it || !it.published) return notFound();
    if (it.type === 'episode') { location.replace('#/watch/' + enc(id)); return { html: '' }; }
    const epic = Data.isEpisodic(it), eps = epic ? Data.episodes(it.id) : [], seasons = epic ? Data.seasons(it.id) : [];
    const pa = primaryAction(it), prog = Store.progress(it.id);
    const meta = [it.releaseYear, it.language, it.rating ? '★ ' + it.rating : '', epic && eps.length ? `${seasons.length} season${seasons.length > 1 ? 's' : ''} · ${eps.length} episode${eps.length > 1 ? 's' : ''}` : ''].filter(Boolean).join(' · ');
    const primary = pa ? `<a class="btn primary" href="${pa.href}">${icon('play')}${esc(pa.label)}</a>` : `<button class="btn primary" disabled>No episodes yet</button>`;
    const actions = `<div class="actions">${primary}${CF.toggleBtn('wl', it.id)}${CF.toggleBtn('fav', it.id)}<button class="btn ghost" data-action="share" data-id="${esc(it.id)}">${icon('share')}Share</button><button class="btn ghost" data-action="dl" data-id="${esc(it.id)}">${icon('download')}Download</button></div>`;
    const body = epic
      ? `<div class="tabs" role="tablist"><button class="on" role="tab" aria-selected="true" data-action="tab" data-target="t-eps">Episodes</button><button role="tab" aria-selected="false" data-action="tab" data-target="t-det">Details</button></div>
         <div class="tabpanel" id="t-eps"><div class="eps-head"><h3 class="h3" style="margin:0">${eps.length} episode${eps.length === 1 ? '' : 's'}</h3>${seasonSel(it.id, '', seasons)}</div><div id="eps">${epRows(eps.filter(e => e.seasonNumber === (seasons[0] || 1)))}</div></div>
         <div class="tabpanel" id="t-det" hidden>${infoBlock(it)}${relatedBlock(it)}</div>`
      : `${infoBlock(it)}${relatedBlock(it)}`;
    return {
      title: it.title,
      html: `<div class="detail"><div class="cover">${CF.img(it.banner || it.thumbnail || it.poster, it.title, '16:9', '', 'eager')}<div class="cover-fade"></div><div class="cover-top"><button class="iconbtn" data-action="back" aria-label="Go back">${icon('back')}</button><a class="iconbtn" href="#/search" aria-label="Search">${icon('search')}</a></div></div>
      <div class="page"><div class="dhead"><div class="dposter">${CF.img(CF.posterOf(it), it.title, '3:4', '', 'eager')}</div><div class="dinfo"><h1>${esc(it.title)}</h1><p class="meta">${esc(meta)}</p><div class="tags"><span class="tag">${esc(CF.label[it.type])}</span>${it.status ? `<span class="tag accent">${esc(it.status === 'ongoing' ? 'Ongoing' : 'Completed')}</span>` : ''}${it.genres.slice(0, 3).map(g => `<span class="tag">${esc(g)}</span>`).join('')}</div></div></div>${actions}${body}</div></div>`
    };
  };

  /* ---------- WATCH ---------- */
  V.watch = ([id]) => {
    const it = Data.byId[id]; if (!it || !it.published) return notFound();
    const par = it.type === 'episode' ? Data.byId[it.dramaId] : null;
    const sibs = par ? Data.episodes(par.id) : [], idx = sibs.findIndex(e => e.id === it.id);
    const prev = idx > 0 ? sibs[idx - 1] : null, next = idx >= 0 && idx < sibs.length - 1 ? sibs[idx + 1] : null;
    const title = par ? `${par.title} – S${it.seasonNumber} E${it.episodeNumber}: ${it.title}` : it.title;
    const meta = par ? [`Season ${it.seasonNumber}`, it.releaseDate] : [it.category || CF.label[it.type], it.language, it.releaseYear, it.views != null ? CF.fmtViews(it.views) + ' views' : ''];
    const media = { id: it.id, parentId: it.dramaId || null, title, src: it.videoUrl, aspect: it.aspectRatio, subtitles: it.subtitles, poster: CF.thumbOf(it) || (par && CF.posterOf(par)) || '', editId: it.id };
    const dl = `<button class="btn ghost" data-action="dl" data-id="${esc(it.id)}">${icon('download')}Download</button>`;
    const detailLink = par ? `<a class="btn ghost" href="#/title/${enc(par.id)}">${icon('info')}All episodes</a>` : (it.type !== 'video' ? `<a class="btn ghost" href="#/title/${enc(it.id)}">${icon('info')}Details</a>` : '');
    const np = (prev || next) ? `<div class="nextprev">${prev ? `<a class="btn ghost sm" href="#/watch/${enc(prev.id)}" data-autostart>${icon('prev')}Previous</a>` : ''}${next ? `<a class="btn cyan sm" href="#/watch/${enc(next.id)}" data-autostart>Next Episode${icon('next')}</a>` : ''}</div>` : '';
    let side;
    if (par) side = `<div class="eps-head"><h3 class="h3" style="margin:0">Episodes</h3>${seasonSel(par.id, it.id, Data.seasons(par.id))}</div><div id="eps">${epRows(sibs.filter(e => e.seasonNumber === it.seasonNumber), it.id)}</div>`;
    else {
      const rel = it.type === 'video' ? Data.query({ types: ['video'] }).filter(v => v.id !== it.id).slice(0, 8) : Data.related(it, 8);
      side = rel.length ? `<h3 class="h3" style="margin-top:0">${it.type === 'video' ? 'Up next' : 'Related'}</h3>${rel.map(r => `<a class="up" href="${CF.href(r)}"><div class="thumb">${CF.img(CF.thumbOf(r) || CF.posterOf(r), r.title, '16:9')}</div><div style="min-width:0"><div class="pt" style="white-space:normal">${esc(r.title)}</div><div class="pm">${esc([CF.label[r.type], r.category].filter(Boolean).join(' · '))}</div></div></a>`).join('')}` : '';
    }
    const autoStart = CF.state.autoStart; CF.state.autoStart = false;
    return {
      title,
      html: `<header class="hdr"><button class="iconbtn" data-action="back" aria-label="Go back">${icon('back')}</button><span class="sp"></span>${searchBtn}</header><div class="page"><div class="watch-cols"><div><div id="playerHost"></div><div class="watch-info"><h1>${esc(title)}</h1><p class="meta">${esc(meta.filter(Boolean).join(' · '))}</p>${np}<div class="actions">${CF.toggleBtn('wl', it.id)}${CF.toggleBtn('fav', it.id)}<button class="btn ghost" data-action="share" data-id="${esc(it.id)}">${icon('share')}Share</button>${dl}${detailLink}</div>${it.description ? `<p class="desc">${esc(it.description)}</p>` : ''}${it.sample ? '<p class="demo-note">Demonstration content.</p>' : ''}</div></div><aside>${side}</aside></div></div>`,
      mount(v) {
        const go = n => { CF.state.autoStart = true; location.hash = '#/watch/' + enc(n.id); };
        const pl = CF.Player($('#playerHost', v), media, { hasNext: !!next, hasPrev: !!prev, onNext: () => next && go(next), onPrev: () => prev && go(prev), autoplayNext: Store.settings().autoplay, autoStart });
        CF.onLeave(pl.destroy);
        $$('[data-autostart]', v).forEach(a => a.addEventListener('click', () => { CF.state.autoStart = true; }));
      }
    };
  };

  /* ---------- SEARCH ---------- */
  function resultsHTML(q) {
    q = q.trim();
    if (!q) {
      const gs = [...new Set(Data.items.filter(i => i.published && i.type !== 'episode').flatMap(i => i.genres))].slice(0, 12);
      return `<div class="empty"><div class="empty-ic">${icon('search')}</div><h3>Search Cine Focus</h3><p>Find movies, series, dramas, episodes, videos and short films by title, genre, language or tag.</p></div>${gs.length ? `<div class="chips" style="justify-content:center;flex-wrap:wrap">${gs.map(g => `<button class="chip" data-action="sq" data-q="${esc(g)}">${esc(g)}</button>`).join('')}</div>` : ''}`;
    }
    const r = Data.search(q, 40);
    if (!r.length) return empty('No results for "' + q + '"', 'Check the spelling or try a genre, language or a shorter word.');
    return `<p class="hint" style="margin:6px 4px" aria-live="polite">${r.length} result${r.length > 1 ? 's' : ''}</p>` + r.map(it => {
      const par = it.type === 'episode' ? Data.byId[it.dramaId] : null;
      const sub = par ? `${par.title} · S${it.seasonNumber} E${it.episodeNumber}` : [CF.label[it.type], it.language, it.releaseYear].filter(Boolean).join(' · ');
      return `<a class="srow" href="${CF.href(it)}"><div class="thumb">${CF.img(CF.thumbOf(it) || CF.posterOf(it), it.title, '16:9')}</div><div style="min-width:0"><div class="pt" style="white-space:normal">${esc(it.title)}</div><div class="pm">${esc(sub)}</div></div></a>`;
    }).join('');
  }
  V.search = (a, q) => {
    const init = q.get('q') || '';
    return {
      title: 'Search',
      html: `<header class="hdr"><button class="iconbtn" data-action="back" aria-label="Go back">${icon('back')}</button><form class="searchbar" role="search" onsubmit="return false">${icon('search')}<input id="q" type="search" placeholder="Search movies, dramas, videos…" aria-label="Search" autocomplete="off" value="${esc(init)}"><button type="button" class="iconbtn" id="qclear" data-action="sq" data-q="" aria-label="Clear search" ${init ? '' : 'hidden'} style="width:36px;height:36px">${icon('close')}</button></form></header><div class="page"><div id="qres">${resultsHTML(init)}</div></div>`,
      mount() {
        const inp = $('#q'); let t;
        const run = () => { $('#qres').innerHTML = resultsHTML(inp.value); $('#qclear').hidden = !inp.value; };
        inp.addEventListener('input', () => { clearTimeout(t); t = setTimeout(run, 180); });
        CF.onLeave(() => clearTimeout(t)); if (!init) inp.focus();
      }
    };
  };
  A.sq = el => { const i = $('#q'); if (!i) return; i.value = el.dataset.q; i.dispatchEvent(new Event('input')); i.focus(); };

  /* ---------- shared actions ---------- */
  A.wl = el => { const on = Store.toggle('watchlist', el.dataset.id); CF.refreshToggles(); CF.toast(on ? 'Added to watchlist' : 'Removed from watchlist'); };
  A.fav = el => { const on = Store.toggle('favorites', el.dataset.id); CF.refreshToggles(); CF.toast(on ? 'Added to favorites' : 'Removed from favorites'); };
  A.share = async el => {
    const it = Data.byId[el.dataset.id], id = el.dataset.id;
    const url = location.href.split('#')[0] + '#/' + (it && (it.type === 'video' || it.type === 'episode') ? 'watch' : 'title') + '/' + enc(id);
    try { if (navigator.share) { await navigator.share({ title: it ? it.title : 'Cine Focus', url }); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
    try { await navigator.clipboard.writeText(url); CF.toast('Link copied'); } catch (e) { window.prompt('Copy this link', url); }
  };
  A.unlist = el => { Store.set(el.dataset.list, Store.list(el.dataset.list).filter(x => x.id !== el.dataset.id)); CF.render(true); };
})();
