# Cine Focus

Static streaming web app: HTML5, CSS3, vanilla JavaScript. No build step. Firebase-ready bootstrap is included; cloud features require project setup.

## Run locally
Serve the folder over HTTP (opening index.html as file:// cannot load the JSON data):

    cd cine-focus
    python3 -m http.server 8080
    # open http://localhost:8080

## Deploy free
Upload the folder as-is to GitHub Pages, Netlify (drag & drop), Cloudflare Pages or Vercel (static). All paths are relative.

## Add your content
- `data/content.json` – movies, series, dramas, episodes (`type: "episode"`, `dramaId`, `seasonNumber`, `episodeNumber`), videos, short films.
- `data/banners.json` – hero carousel slides.
- `data/sections.json` – home / videos / drama sections (rules, order, visibility) and filter chips.
- Set `videoUrl` to a direct MP4 (or HLS .m3u8) you are authorised to publish, and `aspectRatio` to `16:9`, `9:16`, `1:1` or `auto`.
- Put images in `assets/` or use URLs. Missing images get generated placeholders.
- Optional `downloadUrl` enables the Download button.

Or use Profile > Content Manager: edits are saved **in your browser only**. Use its Data tab to export the three JSON files, replace the ones in `data/`, and redeploy to publish for everyone.

## Honest limitations
- Local admin, profile, watchlist and history are per-browser; there is no login or sync.
- Offline downloads work only when the host allows CORS and the browser has storage; otherwise the normal browser download is used and is not tracked.
- Sample content has no video URLs, so playback shows a "No video source" message until you add links.
- DRM, YouTube/Vimeo page links and MKV are not playable by the native player.


## Firebase setup (owner/developer)
1. Create a Firebase project and register a Web app.
2. Copy the Web app config into `js/firebase-config.js` (replace every `YOUR_...` placeholder).
3. If you want to initialize Firebase immediately, add the Firebase compat SDK scripts for App, Auth and Firestore before `js/firebase.js` in `index.html` (use the current official Firebase CDN versions).
4. Enable Authentication providers and create a Firestore database in the Firebase console. Write restrictive Firestore Security Rules before publishing. Never use Admin SDK credentials or service-account keys in this public app.
5. The public Cine Focus app intentionally has no admin/content-manager screen. Build and deploy a separate, protected admin app for content editing; secure it with Firebase Authentication and server-enforced Firestore rules.

Firebase initialization is a scaffold only: watchlist/profile/content are not yet synced to Firestore until the data layer is explicitly connected. Video durations are intentionally hidden from the public interface.

UI update notes: Videos page now uses the editable 16:9 banner carousel from data/banners.json above the video feed. Drama page uses tall portrait posters in a horizontal rail with Watch and Download controls. Content cards also expose Watch and Download controls. Add/edit banner entries through Content Manager; use direct image URLs and content IDs. For downloads to work, add a valid downloadUrl to each item/episode. data/platforms.json is a starter list/reference for streaming platform labels; current topic strip can be customized in js/views.js unless platform management is connected to the data loader.
